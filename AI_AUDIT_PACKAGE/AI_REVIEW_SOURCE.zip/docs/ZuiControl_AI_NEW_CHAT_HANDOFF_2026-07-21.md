# ZuiControl 新聊天完整交接 - 2026-07-21

## 0. 权威入口

新聊天按以下顺序读取：

1. `D:\3.VScode\Mi\AGENTS.md`
2. 本文件
3. 需要理解 P2 XML 时读取 `docs/ZuiControl_P2_XML_THERMALCONFIG_GUIDE_2026-07-21.md`
4. 需要追溯实测证据时读取：
   - `docs/ZuiControl_HANDOFF_P3_APPOPT_CLOUD_P2FIX_2026-06-24.md`
   - `docs/ZuiControl_HANDOFF_P2_MINGCHAO_XML_FIX_2026-06-24.md`

旧的 `D:\3.VScode\Mi\docs\ZuiControl_CONTEXT.md`、`ZuiControl_V19_VERIFY_AND_NEXT.md`、`ZuiControl_HANDOFF.md`、`ZuiControl_ROADMAP.md` 保存完整历史，但其中“当前阶段”“推荐包”“下一步”若与本文件冲突，以本文件为准。

### 0.19 2026-08-28 全项目只读审查、切档实测与 GPU 双调度链（当前最新）

本节覆盖 0.18 对“当前调度已完成验收”的判断，但不改写其刷包、P1、线程 mask、SELinux 和 UI 历史事实。设备仍是已持久刷入的 `49/0.21.12/ZuiControlV49`，当前不是待刷状态。本轮没有修改产品代码、thermal conf、P1、FPS cap 或设备系统，没有制作/刷写镜像，也没有主动高温烧机。

#### 审查交付与验证边界

- 按用户提供的完整审查清单读取仓库 91 个 Git 跟踪文件、当前主入口、主交接和 ThermalConfig guide；生成 `AI_AUDIT_PACKAGE`，包括 20 份编号报告、`README_FOR_AI_REVIEW.md`、91 行 `SOURCE_FILE_INDEX.csv` 和排除秘密/构建物/设备 dump 的 `AI_REVIEW_SOURCE.zip`。
- `:app:testDebugUnitTest :app:lintDebug :app:assembleDebug` 通过：5 tests 全过，Lint 0 errors/17 warnings，Debug APK SHA-256 为 `ab9b20d1f2c048546cac35e791c1fb0cce5dfbf5dac76712486fee1035688cbb`。Python/JSON/source XML/shell、daemon transaction 和 framework 最小 javac 也通过。
- 没有 instrumentation/UI、完整 072 framework/secilc、release 签名、最终 super、本轮刷写、Doze/低内存/配置损坏/system_server 故障和长时稳定性验证；不能据此宣称多场景全部稳定。

#### Uperf 切档的真实响应语义

- App 通过 Settings 单槽写 request，`zui_controld` 的 `main_loop()` 每约一秒处理/同步，App 每 200ms 查询终态 ACK。因此它是约 1-2 秒响应，不是 Binder event 级即时；本轮可逆真机测试有效变化约 0.97-2.07 秒。
- 解析顺序仍是熄屏 powersave > exact app > global。鸣潮 exact=performance 时，切 global=fast 的 ACK 明确显示 `effective=performance`；把鸣潮 exact 临时改为 powersave 后约 2.07 秒生效。测试结束已恢复 global/effective=balance、鸣潮 exact=performance、熄屏 `- powersave`。
- 从鸣潮切到 ZuiControl 时 raw focus 是 ZuiControl，但 system_server 的 business scene 保持鸣潮，所以修改鸣潮 exact 可在 ZuiControl 前台作用，返回游戏沿用。只修改 global 不会覆盖已有 exact。
- 当前设备 perapp 是一条 `com.kurogame.mingchao performance` 加一条 `- powersave`，不是 0.18 所写“两条鸣潮”。

#### GPU 500-629MHz 的新 P0 根因

- 当前 `payload/system/etc/zui_control/uperf-sm8650.json` 只有 CPU power-model、WALT governor、core_ctl/cpuset/msm_performance 等模块，没有 KGSL/Adreno GPU 频率模块。当前 Uperf 无法请求 903/834/770 等 GPU 档。
- 真机自然低温 Launcher 基线：KGSL governor=`msm-adreno-tz`，频表含 903 至 231MHz，current=231、min=231、max_clock=720、thermal_pwrlevel=3；quiet/back/front/battery 约 31-32C，Thermal Status 0，两个标准 GPU cooling devices 均为 state 0。故 pwrlevel 3 不是当前标准 GPU cooling state 直接造成，仍可能是残留/另一 OEM 约束。
- 真实从 Launcher 短时进入鸣潮时，OEM `onGameAppStart` 仍触发；`com.zui.pp` PerformanceConnect 下发鸣潮 stock LimitConfig，其中 `GPUMax=5`、`GPUMin=9`，按当时频表对应约 629MHz/366MHz。GameHelper 同时 `writeSavageMode open=1`，thermal-engine 切入游戏 cpu/gpu/battery case；退出后回到默认 case。
- 这证明 0.18 的“旧 XML/ZuiPP 生产链退出”只对 ZuiControl 自己的生成/bind/bridge 成立，并没有让 OEM GameHelper/ZuiPP 的原生 LimitConfig 停止。当前实际是 Uperf 推 CPU/WALT/core_ctl，OEM 仍给 CPU/GPU 限制；用户看到 CPU 3.3GHz 与 GPU 500-629MHz 不对称符合这条双调度链。0.18 的游戏助手非零截图只证明 telemetry 修复，不证明 GPU 调度正确。
- CPU 3.3GHz 仍需同窗口每核 `scaling_cur_freq` 采样，不能只凭叠加层断言所有核持续锁满；但 OEM/Uperf 双 owner 已由日志直接确认。

#### 当前结论与下一阶段门

- 当前不能继续宣称“Uperf 已全面接管并稳定”。第一 P0 是选择唯一 GPU/游戏性能 owner；第二 P0 是性能命令仍使用未认证 Settings 单槽，任何可写该 setting 的高权限调用者都可改档/重启调度。另有 `ZuiControlClient.call()` 把 `ok=0` 误判成功的 P1 确定 bug。
- 当前规则禁止 direct CPU/GPU sysfs、旧 XML/ZuiPP/AppOpt/Scene 生产链、thermal conf 和 P1 改动，因此本轮不做快速 KGSL 修补。下一阶段必须由用户明确选择：A）承认 Uperf 只管 CPU/WALT、OEM 管 GPU；或 B）另行授权 Uperf/KGSL 原生 GPU 方案，并精确关闭 OEM LimitConfig、保留 GameHelper telemetry 与热保护。
- 后续先做自然冷却、同版本、同场景的短时同步 A/B：scene/global/exact/effective、每核 freq/policy、KGSL current/min/max/busy/pwrlevel/cooling、OEM/ZuiPP/thermal 日志。不要主动烧机。

### 0.18 2026-08-25 V49 内置 Uperf/asoulOpt、最终刷入与调度验收（历史，已被 0.19 覆盖）

本节覆盖 0.17 的 Scene/P2/AppOpt 当前方向与下一步；0.17 及以前只保留为历史证据。设备 `HA25HSZM` 已通过固定七项 9008 流程持久刷入 `49/0.21.12/ZuiControlV49`，当前不是待刷状态。生产性能调度已从 P2 XML/AppOpt/Scene 切换为 ROM 内置 Uperf + asoulOpt；没有修改 thermal conf、P1 或 FPS cap，也没有恢复 direct CPU/GPU sysfs、provider_direct、云控或旧 XML/ZuiPP/AppOpt 生产链。

#### 当前生产成品与发布事实

- 设备/系统：TB321FU / `TB321FU_CN_OPEN_USER_Q00040.0_U_ZUI_16.1.11.072_ST_241118`；槽 `_a`，Verified Boot `green`，SELinux `Enforcing`。
- 生产 HEAD：`032c82e03192287f8e788fbf8fb9d1a0bb7f919b`（`fix: allow integrated scheduler runtime IPC`），已与 `origin/main` 同步。Uperf 主体为 `fdf2051`，恢复 UI/OEM 遥测为 `bc53077`，删除 QQ 音乐预装为 `015800a`。
- GitHub Actions run `32809284592` success；保留 artifact：`D:\3.VScode\Mi\work\ci_artifacts\zuicontrol_32809284592`。release 证书 SHA-256：`3fecf3a72ca0e0f24991d49e7306ef4a711711f48a66070755eb0237ecb3ed94`。
- 最终成品：`D:\3.VScode\Mi\【B刷机】072`。最终 `super.img` 已反抽全部动态分区、system EROFS、策略文本和 `services.jar`，verifier 返回 `ok=true`；Windows 侧仍没有独立完成 `secilc` 编译级验证，最终以本节刷后 Enforcing/AVC 实测为准。
- 固定安全包只含七项：LUN0 的 `super`、`vbmeta_system_a/b`，LUN4 的 `boot_a/b`、`vbmeta_a/b`。正式最终刷写日志：`D:\3.VScode\Mi\flash\Log\ZuiControl_qdlrs_2026-08-25_12-51-00.log`；Firehose 返回 `All went well! Resetting to system`，脚本随后确认 072、boot completed 与 49/0.21.12。

```text
e7e85b5cd2806b8c27adf4925e05ee169072a79a43502effc34c97fb27ee8371  boot.img
9b4c06aeb2a366846954c1ba1a48451b6fcc6e7b9a2589e17a8834906f5a8e33  super.img
4d476c646efaae1daad99888504dbbbc39de03b50b9c746e74252ebf31f54946  vbmeta_system.img
bb756ee076bff3d3bab92b62a53e2926fc37c665235c6522924c7d5e23699774  vbmeta.img
3389454bacd9532182bba4e705f2c68c709ffa3451edacae2d96b30f58c0d659  ZuiControl-v19-release.apk
3389454bacd9532182bba4e705f2c68c709ffa3451edacae2d96b30f58c0d659  ZuiControl-v19-system.apk
```

- `boot.img` 仍逐字来自用户指定的 `D:\3.VScode\Mi\072必刷镜像\boot.img`，用于当前 APatch 开发/诊断环境；Uperf、asoulOpt 与 ZuiControl 本身均由 ROM init/system_server 托管，不调用 su、Magisk module 或 `/data/adb`。以后恢复原版 072 boot 后，调度链按设计仍可运行。
- 为满足 system AVB data 上限，只从本次 072 system 工作树删除 `/system/preload/QQMusic/QQMusic.apk`（180737432 bytes）；WPS 保留，官方 A072 原包未改。实机 `pm` 中 QQ 音乐不存在、`cn.wps.moffice_eng` 存在。

#### 当前调度架构与模式语义

- init 直接托管 `/system/bin/uperf`、`/system/bin/zui_uperf_service` 和 `/system/bin/AsoulOpt`。Uperf 处理模块明确配置的 CPU power-model、WALT governor、core_ctl 等；不宣称直接接管 Adreno KGSL 频率，也不移除系统热保护。
- 全局模式只有 `powersave`、`balance`、`performance`、`fast`：分别对应节能、日常均衡、更积极的持续性能、最积极的短时/峰值响应；它们是成套调度参数，不是四个固定 GHz。
- 有效档位解析顺序固定为：熄屏 `powersave` > 精确应用覆盖 > 全局模式。`cur_powermode.txt` 只存全局档；`perapp_powermode.txt` 当前为两条鸣潮 `performance` 与一条 `- powersave` 熄屏规则，不含 `*` 全局兜底。
- Uperf 自带线程调度保持关闭。线程放置只由 asoulOpt 执行；当前 `mode=0`、`rt=0`，保留旧 Shiroko 二进制的硬亲和与 WALT per-task boost，不启用实时调度。
- 旧二进制的硬编码路径已等长修改为 `/data/vendor/asopt.conf`，init 将它软链接到持久、可编辑的 `/data/vendor/zui_control/asoul/asopt.conf`。实机链接 context 为 `zui_control_data_file`，`/data/adb/naki` 不存在。
- 旧 asoulOpt 二进制的应用/线程匹配表仍编译在闭源二进制中；外部 conf 只有 mode/rt/opt。不能把任意新 App 的线程规则编辑能力冒充成已经交付；若要通用可扩展规则，必须有源码兼容实现或替换引擎，不能同时运行 AppOpt。

#### 最终 Enforcing 实机验收

- PackageManager 与 `/system/priv-app/ZuiControlV49/ZuiControl.apk` 均为 49/0.21.12；系统 APK SHA-256 与 CI 的 `3389454...d659` 一致。`zui_control` 存在，Launcher raw/current/last/applied 正确，target/actual 为 120/120，`refreshOwner=system`、`daemonRefreshDisabled=true`、`displayVote=adaptiveRender`。
- shell UID 可读取公开版本事务；调用受保护状态事务得到 `caller package is not ZuiControl`，证明包名/签名授权门禁实际执行。
- 干净重启后及一次受控 `zui_control.scheduler=restart` 后：`zui_controld` 一个 init 子进程；A-SOUL 一个 init 子进程；Uperf 一个 wrapper、一个主进程和一个子进程。五次、约 40 秒无负载采样中 PID 不变，三项调度 init service 与 `performance`、`poweropt-service`、`perf2-hal-1-0` 三项 OEM 遥测服务始终 running；`vendor.perfservice` 保持 stopped。
- 四个全局档逐一通过 daemon 正式 request/ACK 协议，`cur` 与 `effective` 依次成为 `powersave/balance/performance/fast`；最终终态 ACK 为 `global=balance;effective=balance`。熄屏实测 `balance -> powersave`，亮屏后恢复 `balance`。
- 第一版刷后曾发现 `system_server -> performanced binder call` 与 A-SOUL 读取 `/data/vendor/asopt.conf` 软链接两条 AVC。最终 032c82e 精确加入 Binder call 与 `zui_control_data_file:lnk_file { getattr read }`；重制、二次刷入并从干净开机复测后，调度重启和真实 ZuiControl Activity 生命周期均未再出现这两类 AVC，相关 crash/ANR 为零。072 原生/当前 root 环境仍有 system_server capability、CachedAppOptimizer、Lenovo 键盘等非项目 AVC，不为它们扩大 ZuiControl 策略。
- 鸣潮当前已安装：`com.kurogame.mingchao` 3.6.0，versionCode 176520875，base APK SHA-256 `1ed062517f87dd9685be7b6d33206f36a823ba56516b28b26e1ffb366800433b`。最终二次刷入后已从亮屏 Launcher 的真实“鸣潮”图标正常进入；system_server 的 raw/current/last/applied 均为鸣潮，target/actual 为 120/120，全局仍为 `balance`、Uperf effective 精确切到 `performance`，退出后又恢复 `balance`。
- 开放世界真实 PID 8908 共采到 208 个存活线程：206 个为 `2-6`，`GameThread` TID 9284 为 `7`，`RenderThread 2` TID 10203 为 `2-4`；主线程 TID 8908 为 `2-6`。这闭合了旧 Shiroko 表在真实鸣潮上的硬亲和效果，不是测试包结论。
- P1 未改，profile 当前只有 `default|0|120|0|DISPLAY_ONLY`。AppOpt、XML bind/ZuiPP bridge、SafeCenter/su 生产逻辑和旧命名进程均不存在。

#### UI、游戏助手与最终视觉/游戏验收

- V49 竖屏已复核刷新率页和 Uperf 页，横屏已复核 Uperf 页和线程页：原有底栏/侧栏、选中态、字体、间距、圆角、FAB 与页面结构一致；全局四档同一行，下面是两条鸣潮自定义应用卡片和“+”入口，没有溢出或错位。
- OEM `performance`、`poweropt-service`、`perf2-hal-1-0` 始终 running。正常 Launcher 入场后，原厂 `FloatingHwInfo` 窗口实际存在；两次截图分别显示 CPU 3.30GHz / GPU 366MHz / 10FPS / 32.0C，以及 CPU 3.30GHz / GPU 500MHz / 59FPS / 33.2C，确认 CPU/GPU/FPS 不再全为 0，且读数来自 `com.zui.game.service` 原厂游戏助手而非 ZuiControl 自制层。
- 证据目录为 `D:\3.VScode\Mi\work\validation_v49_20260825`；核心图片是 `zui_v49_app_portrait.png`、`zui_v49_uperf_portrait.png`、`zui_v49_uperf_landscape.png`、`zui_v49_thread_landscape.png`、`second_launch_8s.png` 和 `gameassistant_nonzero_final.png`。
- 实测只做短时入场/采样。开放世界首轮 CPU/GPU junction 上升后已立即强停；最终遥测复核虽只持续约十秒，退出后 thermalservice 的 CPU junction 峰值仍瞬时到 89.9C，因此再次立即停止。20 秒后 cpuss 已回到 36.3-37.4C、gpuss 35.4-36.6C、skin 35.9C、battery 33.9C。不要把游戏助手显示的 33.2C 当成最高 junction，也不要继续主动高温烧机。
- 游戏退出终态：鸣潮无 PID，焦点回 Launcher，target/actual 120/120，global/effective 均为 `balance`，自动旋转恢复 `accelerometer_rotation=1` / `user_rotation=0`；游戏阶段及退出后目标调度 AVC、FATAL、ANR 均为零。

#### 工作区清理

- 新增 `scripts/CleanupZuiControlReleaseWorkspace.ps1`：固定 allowlist、保留成品/当前 CI 门禁、工作区边界检查、默认 dry-run，只有 `-Execute` 才清理。
- 已删除本轮可重建的 `work/unpack`、`work/img`、`work/flash_img`、中间 `work/super.img`、QQ 音乐隔离副本、两份旧 CI 和三个反编译/审计临时目录。D 盘可用空间由 62.38GiB 增至 103.36GiB，实际恢复约 40.98GiB；官方 A072、`072必刷镜像`、最终 B072、固定安全包、当前 CI、仓库与刷写日志均保留。
- 最终游戏助手调查完成后又删除 `gamehelper_v49_ui_audit`、`services_v49_gesture_audit` 及两份拉取的 APK/JAR，约 590MiB 可重建材料；只保留 `work/validation_v49_20260825` 中的截图、UI XML 和小型标记证据。

### 0.17 2026-08-23 Scene 实机调度对照与 P2 KGSL 落实缺口（历史，已被 0.18 覆盖）

本节覆盖 0.16 的鸣潮卡顿判断和“冷机重启 A/B”下一步，但不改写 0.15/0.16 已完成的 072/V43 刷写与杜比调查事实。设备仍为已持久刷入并验收的 `43/0.21.6/ZuiControlV43`，不是待刷状态。仓库 `main` 当前 HEAD 为 `71bf71c fix: synchronize Dolby quick settings state`，相对 `origin/main` ahead 1；这是 `44/0.21.7/ZuiControlV44` 杜比草案，尚未推送 CI、制作镜像或刷入设备。本轮没有修改 thermal conf、P1、FPS cap、P2 XML、CPU/GPU sysfs、Scene 配置或 AppOpt 配置。

#### 本轮对照条件

- 当前系统 P2 仍保持启用；AppOpt 已由用户停用，`init.svc.zui_appopt=stopped`，没有 AppOpt/AsoulOpt PID。
- 用户安装并启用了 Scene 9.4.11（`com.omarea.vtools`）。Scene EP 已开启，鸣潮单独为 `fast`/极速模式，Scene 自带鸣潮线程放置也已开启；`scene-daemon` 运行于 `u:r:magisk:s0`。
- 因此本轮可用的真实对照是：此前同一 072/V43 的 **P2-only**，对比当前 **P2 + Scene EP + Scene 线程放置**。不能把它写成“纯 Scene、P2 完全关闭”的实验。
- 使用 ADB 正常亮屏、解锁、启动鸣潮、处理更新重启、点击连接并进入开放世界；没有修改任何性能或热控节点。接近预设 90C 保护线后立即回桌面，最终强停鸣潮并恢复 `svc power stayon false`。

#### 实机关键数据

| 阶段 | 画面/叠加层 | KGSL 实际/min/max | thermal_pwrlevel | CPU/温度要点 |
|---|---|---|---:|---|
| 冷态重新进入开放世界 | 60FPS，CPU 瞬时 3.30GHz，GPU 903MHz，显示温度 33.8C | `903/903/903MHz` | 0 | 证明 072 的 3.3024GHz 与 GPU 903MHz 都能实际进入 |
| 登录/加载升温中 | 56–60FPS，GPU 629MHz，显示温度约 43–44C | `629/903/629MHz` | 5 | Scene 仍请求 min=903，但 KGSL 热控上限裁到 629 |
| 热态开放世界 | 约 45FPS，GPU 500MHz，显示温度 45.4C | `500/903/500MHz` | 7 | CPU2–5 最高约 89.9C，GPU 热点最高约 89.6C；到线即停止 |
| 回桌面/强停后 | 无游戏进程 | `231/231/903MHz` | 0 | 最终 cpuss 约 38.6–39.4C、八个 gpuss 约 37.7–38.9C，正常释放 |

- `thermal-engine-v2` 与 QTI Thermal HAL 全程运行，HAL cooling device 曾为 `gpu=3`。Scene 没有绕过或关闭系统热控；热控介入后实际 GPU 由 903 依次降为 629、500MHz。
- 游戏叠加层显示的约 34–45C 不是 CPU/GPU 最高 junction。用户看到“温度高仍 903MHz”可以发生在界面温度已升高但 junction 尚未触发 KGSL cap 的阶段；一旦本轮 junction 接近 90C，903MHz 已不能继续保持。
- SurfaceFlinger `--latency` 在本轮图层生命周期中只返回刷新周期 `8333333`，Scene 的“帧率记录”也为空，因此本轮没有合格的 P95/1% low 帧时间统计。不要把叠加层瞬时 FPS 冒充微卡量化结论。

证据截图保存在：

```text
D:\3.VScode\Mi\work\scene_runtime_test\14_mingchao_settings.png  冷态 903MHz/60FPS/3.30GHz
D:\3.VScode\Mi\work\scene_runtime_test\07_resource_state.png     升温中 629MHz/60FPS
D:\3.VScode\Mi\work\scene_runtime_test\09_world_state.png        热态开放世界 500MHz/约45FPS
D:\3.VScode\Mi\work\scene_runtime_test\13_scene_adjust.png       Scene EP 已开启的 UI 现场
```

#### Scene 比当前设计多做了什么

- Scene 的鸣潮 `fast` 配置会设置四簇 CPU 最低/最高请求：约 `1.017/1.804GHz`、`1.498/3.149GHz`、`1.075/1.402GHz`、`1.478/3.302GHz`；实际值仍会随负载和热控收缩。
- WALT 现场读到中核 `hispeed_freq=1708800`、`hispeed_load=90`，up/down rate limit 均为 `2000us`。Scene 不是只做线程亲合度，而是同时管理 CPU 响应参数和频率请求。
- Scene 的鸣潮线程规则为：主线程 `2-6`、GameThread `7`、RenderThread/RHIThread `2-4`、其它线程 `2-6`，关键线程带 RR/负 nice 处理。这与此前 AppOpt 的核心放置几乎相同，所以“线程放置本身”不足以解释流畅度差异。
- Scene 文件存在鸣潮专用 FAS 修正 `com.kurogame.mingchao=-20`；此前对当前 9.4.11 APK 的静态检查还确认其有 FAS/FEAS 帧感知、动态频率响应、cluster target/margin 以及 daemon `@gpu_freq_min`/`@gpu_freq_max` 接口。结合现场 `min_clock_mhz=903`，Scene 的优势来自持续运行的帧反馈/频率控制，而不只是一次性 profile。
- Scene 通用 `limiter_off` 配置中提到 `/proc/game_opt`、`migt`、`perfmgr`，但这些具体路径在当前 072 上不存在，不能把本机流畅归因于这些未命中的兼容项。

#### 对 P2 的新结论

- 当前 P2 active `performanceconfig.xml` 本身已经包含 `<PerfLockConfig code="0x4280C000" param="903000"/> <!-- minGPUFreq -->`，两条 P2 XML 的 `8_0_-1` / `7_0_-1` 方向也仍正确。因此不是“XML 忘写 903”或 GPU level 方向写反。
- 但此前 P2-only 现场在 GPU busy 约 70–72% 时仍出现实际 231MHz，而 Scene 运行时 KGSL `min_clock_mhz` 确实成为 903MHz，退出后恢复 231MHz。当前最可信的根因是：**ZuiPP/GameHelper 的 PerfLock 没有被稳定建立、持有，或在热控/场景变化后没有重新落实；Scene 的运行时控制器持续持有/重申了请求。**
- 所以“XML 数字正确”不等于“KGSL 运行时锁实际生效”。下一步应先查清 `0x4280C000` PerfLock 的建立、生命周期、释放与热控切档后的重申，不要继续盲改 XML 数字，也不要把 AppOpt/Scene 线程放置当成主因。

#### 当前设备终态与最短下一步

- 鸣潮已强停；GPU `231MHz`、允许 `231–903MHz`、`thermal_pwrlevel=0`；USB 保持亮屏已关闭。Scene daemon 保持用户原状态运行，AppOpt 保持 stopped。
- 未经用户当次确认，不要切换 Scene EP/线程放置选项，不要写 CPU/GPU 节点，不要改 P2 XML、thermal conf、P1 或 FPS cap，也不要制作/刷写镜像。
- 若继续量化，先做同温同场景的受控 A/B，并把 Scene 线程放置固定不变，只切换 Scene 的频率/帧感知调度；用 Perfetto/FrameTimeline 或可用的 SurfaceFlinger 图层统计 P50/P95/P99/1% low，同时记录 KGSL min/max/thermal 和 CPU WALT。切换 Scene 设置属于配置变更，必须先征得用户当次确认。
- 修复优先级仍应是原厂链：先让 ZuiPP PerfLock 在官方 HAL/PerfLock 路径可靠持有和重申。只有确认原厂链无法做到、且用户明确同意改变当前架构边界后，才能另做独立、默认关闭、可回滚且不覆盖 KGSL thermal cap 的运行时实验；不要直接把 Scene 式 sysfs 控制塞进生产 P2。
- V44 杜比草案与本调度问题相互独立；只有用户明确决定发布杜比小修时，才推 CI、制包和刷机。

### 0.16 2026-08-22 鸣潮卡顿与杜比状态同步复查（历史，已被 0.17 覆盖）

本节覆盖 0.15 的“当前现场”和下一步，但不改写 0.15 已完成的 072 刷写事实。设备仍是已持久刷入并验收的 `43/0.21.6/ZuiControlV43`，当前不是待刷状态。仓库已起草 `44/0.21.7/ZuiControlV44` 的杜比小修，Debug 构建和单元测试通过；尚未推送 CI、制作镜像或刷入设备。本轮没有修改 thermal conf、P1、FPS cap、P2 XML、direct CPU/GPU sysfs、provider_direct、云控或旧 AsoulOpt。

#### 鸣潮卡顿的只读结论

- 不是 Android 仍在持续编译鸣潮。PackageManager dexopt 显示 `speed-profile / bg-dexopt`，`base.odex`/`base.vdex` 已存在，现场没有 `dex2oat` 进程。UE 首次进入新场景仍可能有 shader/PSO 短卡，但不能解释本次持续不稳。
- 当前两条 P2 profile 仍是 `bin.mt.plus.canary` 与 `com.kurogame.mingchao`。用户在 15:48 重新保存鸣潮后，鸣潮 default/42C/48C 三档 GPU 上限均请求 903MHz；active 与 `/system/etc` hash 闭合：game 两处均为 `5e7d43726796c98b81a2d38ca2c44ad8d57f3bbd18f4cae763a7cf09d6e7eda2`，performance 两处均为 `bf1f2c98762024ac5c811c2cad3736721dc1054e37b6ca6a055abd4fc0da4ec7`。所以这次不是 XML 仍把 GPU 封在 720MHz。
- 当前 AppOpt 规则文件只有注释，`init.svc.zui_appopt=stopped`。daemon 日志明确记录 15:56 从 UI 收到 `remove_appopt_rule pkg=com.kurogame.mingchao`，不是规则自行丢失。受控前台短测时 RenderThread/GameThread/RHI 均为 `0-7`；当前卡顿不能归因于一条正在生效的错误 AppOpt 绑核规则，但也意味着原来的三条优化此刻没有启用。
- 冷态/后台基线已出现 `max=680MHz / thermal_pwrlevel=4`；正常从亮屏桌面进入鸣潮约 10 秒后，GPU 连续固定在 578MHz、忙碌率 70–72%、允许上限 578MHz、`thermal_pwrlevel=6`，而 P2 明确请求 903MHz。CPU 各簇同时接近自身上限，最高 CPU junction 86.8C，低于预设 88C 停止线且未继续加热。直接瓶颈是 KGSL/HAL 安全层覆盖了 XML 请求，不是 CPU 没有 3.3GHz，也不是后台编译。
- 短测后由本轮拉起的鸣潮已强停；杜比保留为 `dlb_dap_state=1`。不要靠改 XML 或写 KGSL 节点掩盖。若要区分“本次开机残留”与“072 每次游戏都会触发的安全 cap”，仍须征得用户当次确认后做一次正常冷机重启 A/B；不要主动烧到 95C。

#### 杜比慢、显示不一致的根因与 V44 草案

- 当前 QS 列表同时存在 ZuiControl `custom(com.zui.zuicontrol/.DolbyTileService)` 和原厂 `dolbyatmos` 两个磁贴。两者外观/名称接近但逻辑不同，是“点了很慢、状态像被重开”的主要混淆源。
- 072 `DaxService` 已原生监听 `Settings.Global.dlb_dap_state` 并据此执行效果总开关。游戏启动日志中的 `change dolby mode by app type` 只是在切换 `dolby_dap_profile`，本轮没有看到鸣潮把 `dlb_dap_state` 从 0 改成 1 的证据。
- 072 `ZuiSettings.apk` 的 `BaseDolbyController` 在无耳机时把开关禁用并把显示值硬编码为 `true`；有耳机时则读取 `Settings.System.recordDolbySwitchStatusWidthHeadSet`。这就是官方设置页在扬声器模式下永远显示“开”的真实原因，不是我们的全局状态没有写成功。
- `ZuiSettings.apk` 使用 `android.uid.system` shared UID，并由 Lenovo OEM 平台证书签名；仓库没有对应私钥。直接重打此 APK 会破坏 system shared UID 签名校验，因此不能为了一个显示问题冒险替换官方 Settings，也不应引入常驻 hook/轮询。
- V44 草案让 ZuiControl Tile 在监听期间注册 `dlb_dap_state` 的 `ContentObserver`，任何外部变更都会立即刷新；点击时同时写真实总状态和原厂耳机记忆键，使以后插拔耳机保持同一选择。BootReceiver 仅在开机做一次幂等 QS 列表归一化：移除重复原厂 `dolbyatmos`，保留并前置 ZuiControl Dolby Tile。没有后台轮询。
- V44 当前只解决“唯一入口、真实状态、耳机记忆和及时刷新”；072 官方 Settings 在无耳机时硬编码为开的显示仍无法在不持有 OEM 平台私钥的前提下安全修补。此时以 ZuiControl Tile 的开/关副标题和 `dlb_dap_state` 为权威状态。

#### 当前最短下一步

1. 先向用户报告上述判断；未经当次确认不要重启。用户确认后做一次正常冷机 A/B：重启前记录，开机 Launcher 记录 903MHz/level 0 是否恢复，再正常进入鸣潮同步采样 GPU、CPU junction 与温度，不主动烧机。
2. V44 代码已通过 `:app:assembleDebug :app:testDebugUnitTest`，但没有 CI artifact、最终 super 或实机验收。只有用户决定要刷杜比小修时，才按当前 release flow 推 CI、反向抽查最终 super 并制作安全 7 项 9008 包。
3. AppOpt 当前是用户从 UI 移除规则后的 stopped 状态。不要自动恢复旧三条规则；若用户要继续比较，先让用户明确是否恢复当前 AppOpt 2.2.3 的三条权威规则。

### 0.15 2026-08-22 0.21.6：072 的 3.3GHz、无耳机杜比开关和 AppOpt 2.2.3（历史，已被 0.16 覆盖）

本节覆盖 0.14 的当前版本、成品、AppOpt 状态和下一步。设备 `HA25HSZM` 已通过安全 7 项 9008 流程持久刷入 `versionCode=43` / `versionName=0.21.6` / `ZuiControlV43`，并完成 072 实机验收；当前不是待刷状态。072 的 CPU 修复沿用 187 官方的 `MegaCoreMax=-1` 语义，不是超频；杜比使用新的 ZuiControl QS Tile；AppOpt 使用用户提供的 2.2.3，并以最小 SELinux 权限完成独立 cpuset 初始化。没有修改 thermal conf、P1、FPS cap，也没有恢复 direct CPU/GPU sysfs、provider_direct、云控或旧 AsoulOpt。

#### 当前生产成品与刷写事实

- 设备/系统：TB321FU / `TB321FU_CN_OPEN_USER_Q00040.0_U_ZUI_16.1.11.072_ST_241118`；当前槽 `_a`，Verified Boot `green`，SELinux `Enforcing`。
- App：`43/0.21.6`，PackageManager codePath 为 `/system/priv-app/ZuiControlV43`；V42 已从最终 system 移除。
- 生产 commit：`bfeb578f40ce40323a2fb2898e0474a44d69054d`（`fix: allow AppOpt cpuset initialization`）。CPU/杜比主体为 `031b29c`，V40 升级清理为 `84303bc`，AppOpt 强制 `/proc` JSON/根目录软链接为 `3a9a309`；这些中间 commit 均已包含在 V43。
- GitHub Actions run `32557174653` success：<https://github.com/xmy953538104/ZuiControl/actions/runs/32557174653>；保留的最终 artifact 为 `D:\3.VScode\Mi\work\ci_artifacts\zuicontrol_32557174653`。
- release 证书 SHA-256：`3fecf3a72ca0e0f24991d49e7306ef4a711711f48a66070755eb0237ecb3ed94`；CI/payload/两个 APK SHA-256：`89d9b10a483cb4bc1fc1123fec1201aa0c465cfeb1acd943be556a9b819c1055`。
- 最终成品：`D:\3.VScode\Mi\【B刷机】072`；最终 super 反向抽取 verifier 为 `ok=true`，安全 9008 preflight 只含 `super`、`vbmeta_system_a/b`、`boot_a/b`、`vbmeta_a/b` 七项。
- 正式刷写日志：`D:\3.VScode\Mi\flash\Log\ZuiControl_qdlrs_2026-08-22_14-44-47.log`。Firehose 返回 `All went well! Resetting to system`；重启后脚本确认 072、boot completed 和 43/0.21.6。
- 最终验收后清理了 22 个精确、可重建目标：工作分区 img/unpack、当前与备份中间 super、反编译/签名探针、五份旧 CI artifact、Gradle/Kotlin/build 缓存和 Python `__pycache__`。`work` 现约 1.906GiB，D 盘可用空间由 43.118GiB 增至 103.492GiB，实际恢复约 60.374GiB；官方 A072、用户 `072必刷镜像`、最终 B072、安全 9008 包、最终 CI artifact、仓库和刷写日志均保留。

```text
e7e85b5cd2806b8c27adf4925e05ee169072a79a43502effc34c97fb27ee8371  boot.img
1093c4aff5672a090d39bd1a23a413b71402cdba960edc9b1f022f78d795f3e3  super.img
bbf1d2bb3c2273dc87c427b93590f40c117ae36d68744fe1797a7269cf7986f7  vbmeta_system.img
926aa809ec55f8a521449f8673b48f93e55b412884ab23b087cc4536b73cdcce  vbmeta.img
89d9b10a483cb4bc1fc1123fec1201aa0c465cfeb1acd943be556a9b819c1055  ZuiControl-v19-release.apk
89d9b10a483cb4bc1fc1123fec1201aa0c465cfeb1acd943be556a9b819c1055  ZuiControl-v19-system.apk
```

- `boot.img` 逐字来自用户指定的 `D:\3.VScode\Mi\072必刷镜像\boot.img`。`vbmeta_system.img`/`vbmeta.img` 以同目录用户高回滚模板为唯一模板，在最终动态分区签名后重建；没有把 `【A官方】072` 中对应三张镜像混入成品。

#### 072 的 3.3GHz 根因与修复

- 072 内核本身已经公开 3.3024GHz：policy7 的 `cpuinfo_max_freq=3302400`，boost OPP 中也存在 3.1104/3.1872/3.2448/3.3024GHz。因此不是内核没解锁，也不需要改 boot、内核或直写 cpufreq。
- 072 官方性能 XML 把 Mega 上限显式写成 `3302400`，但 072 ZuiPP 会把“显式等于最高 OPP”的值裁到最后一个普通档 `3052800`。187 官方修复不是写更大的数字，而是把上限改为 `-1`，表示不再人为封顶，让内核自己使用完整 OPP 表。
- `XmlProfileGenerator` 现在仅在用户请求恰好等于 Mega 顶级 OPP 时生成 `MegaCoreMax=-1`；其它值仍按用户输入生成。这是对 187 官方语义的最小移植，不是无条件放开所有 profile，更不是超频。
- V43 实机的 P2 `notifyPerfStatus 11/17` 已显示三个温区均为 `MegaCoreMax=-1`；policy7 的 `scaling_max_freq=3302400`。本次正常亮屏启动鸣潮后，`time_in_state` 的 3302400 档累计为 2792 tick；更早 V41 的独立前后差分也记录到该档 `+47`。因此 3.3024GHz 不只是配置文本或上限显示，而是内核实际进入过的频点。
- 频率仍受 OEM 调度、负载、温度和功耗安全策略动态决定；“允许 3.3GHz”不等于一直锁 3.3GHz。本轮没有主动高温压测，也没有修改任何 thermal conf。

#### 无耳机杜比开关

- “不插耳机不能关”的限制在原厂 SystemUI `QDolbyAtmosTile` 的耳机状态检查，不在 Dolby 效果服务本体。`DaxService` 本身会监听并执行 `Settings.Global.dlb_dap_state`。
- 新增的 `DolbyTileService` 是系统 priv-app 的轻量 QS Tile，使用已有的 `WRITE_SECURE_SETTINGS` 权限直接切换该全局状态；没有 root 轮询、后台常驻或音效服务替换。原厂 Dolby tile 和其耳机限制保持原样，用户使用通知栏最前面的 ZuiControl 杜比开关即可。
- V43 实机确认 `mBluetoothName=null`、`mBluetoothHeadset=null`、`mBluetoothHeadsetDevice=null`。无耳机时点击新 Tile 得到 `1 -> 0 -> 1`，`DaxService` 两次均收到参数更新；最终已恢复为 `1`（开启）。

#### AppOpt 2.2.3 最小修复与最终实测

- 用户提供的新包为 AppOpt 2.2.3。072 没有 BTF，因此生产配置明确使用作者支持的 `/proc` 模式：根目录 `/AppOpt.json` 软链接到 `/system/etc/zui_control/AppOpt.json`，JSON 为 `mode=2`、`check_interval=2`、`cpuset_name=AppOpt`、`web_enable=false`。
- V42 中服务虽然显示 running，但 Enforcing 阻止 `u:r:performanced:s0` 创建 `/dev/cpuset/AppOpt`，三条规则不会稳定生效。一次受控的约 8 秒 Permissive 探针证明二进制和规则本身正确，并把缺口精确缩小为 cgroup 目录的 `create` 与 `setattr`；探针在 finally 中恢复 Enforcing，没有留下宽松模式。
- V43 只增加 `(allow performanced cgroup (dir (create setattr)))`，没有授予广泛 cgroup 文件写权限、root 域、全局 signal 或额外 sysfs 权限。最终开机 `/dev/cpuset/AppOpt` 已存在，AppOpt PID 7816 运行于 `u:r:performanced:s0`，本 boot 中 `comm="AppOpt"`/performanced 相关 AVC 为 0。
- 权威规则仍只有三条：`com.kurogame.mingchao=2-6`、`{RenderThread}=2-4`、`{GameThread}=7`。V43 在亮屏 Launcher 通过正常 Launcher intent 启动鸣潮后，稳定采样为：主进程与 TaskGraph/RHI `2-6`，RenderThread `2-4`，全部精确 GameThread `7`。早期线程创建阶段出现过 OEM 临时重分配，但 AppOpt 的 2 秒扫描后连续样本恢复到上述目标；这才是最终判定。
- 本次短验收设 90C 保护线，最高瞬时 CPU junction 为 80.2C，未触线且没有继续加热。测试后已强停鸣潮；冷却后 CPU junction 最高约 38.1C，八个 gpuss 为 33.8–35.0C。

#### P1/P2 与最终设备现场

- P1 未改：Launcher 的 raw/current/last/applied 一致，target/actual 为 `120/120`，`refreshOwner=system`、`daemonRefreshDisabled=true`、`displayVote=adaptiveRender`、`systemServiceAlive=true`；没有进入 FPS cap。
- P2 两条 canonical profile 为 `bin.mt.plus.canary` 与 `com.kurogame.mingchao`，两者 Mega 请求显示 3.30GHz；鸣潮仍是默认 GPU 422–720MHz、42/48C 为 500–903MHz，active XML 中仍是正确的 `8_0_-1` / `7_0_-1` 方向，`ThermalConfig=0 0 0` 未改。
- active 与 `/system/etc` 最终 bind hash 闭合：game 两处均为 `ef2244f17f75941d13b501ad25c293e05ff2cccbeecb5bd03b3318bcd174bb82`；performance 两处均为 `65913fe5875c403c3baa59c88af687231db0efd141bb224e732f8fabc4fe3b9a`。两条路径均在 PID 1 mountinfo 中确认为 bind mount。
- 同一次亮屏正常鸣潮入口闭合 `onGameAppStart -> initGameHelper -> notifyPerfStatus 11/17 -> writeSavageMode open=1`；JSON 中 Mega 为 `-1`，GPU 三温区与当前 XML 一致。没有恢复 provider_direct。
- 最终鸣潮已强停，SELinux 为 Enforcing，杜比为开启，AppOpt 与 zui_controld 为 running。KGSL 回到 231MHz、允许 231–903MHz、`thermal_pwrlevel=0`；`skin-msm-therm=34.0C`、`quiet-therm=33.0C`、`back_temp=33.5C`、battery=31.7C。072 没有残留 187 的 578MHz/level 6 现场。

#### 当前最短下一步

1. 当前不是待刷状态，不要重复制作或刷写镜像。最终日用包只认 `D:\3.VScode\Mi\【B刷机】072`，校验值以其中 `SHA256SUMS_ZuiControl_v19.txt` 为准。
2. 用户正常使用时观察 3.3GHz、杜比开关和 AppOpt 即可；不要为了证明频率主动烧机。3.3GHz 是允许的 boost 档，不承诺持续驻留。
3. 若以后出现 AppOpt 不响应，先确认 Enforcing、`/dev/cpuset/AppOpt`、PID/域、三条权威规则、真实线程 mask 和 `comm="AppOpt"` AVC；不要退回 Permissive、Magisk 模块或第二套常驻扫描器。
4. 仍然不要改 thermal conf、P1，不进入 FPS cap，不恢复 direct CPU/GPU sysfs、provider_direct、云控或旧 AsoulOpt。温控若以后重开，应作为独立、可回滚实验另起版本。

### 0.14 2026-08-21 072 完整移植、持久刷入与实机验收（历史，已被 0.15 覆盖）

本节覆盖 0.13 的当前设备、成品、下一步和 187 温控残留现场。设备已由用户降级到 `ZUI 16.1.11.072`，随后把 V40 的 P1/P2/P3 架构完整移植到 072 官方基线，使用用户指定的高回滚 boot/vbmeta 模板经安全 7 项 9008 流程持久刷入并完成实机验收。187 上 `thermal_pwrlevel=6/max=578MHz` 未释放的现场只保留为历史，不要在 072 上继续执行原 0.13 的冷机 A/B。

#### 当前生产成品与刷写事实

- 设备：`HA25HSZM` / TB321FU / `TB321FU_CN_OPEN_USER_Q00040.0_U_ZUI_16.1.11.072_ST_241118`；当前槽 `_a`，Verified Boot `green`，SELinux `Enforcing`。
- App：`versionCode=40` / `versionName=0.21.3` / `/system/priv-app/ZuiControlV40/ZuiControl.apk`。
- 072 移植 commit：`e1fbf2718895e48851fb9e5ab3c2cdeed0f90fe7`；AppOpt `/proc` fallback 审计降噪和 072 安全刷写脚本修复 commit：`5163afeef9e798d04563b32bcf165248d3fa6ff6`。
- 当前 CI：GitHub Actions run `32489793335`，结论 success：<https://github.com/xmy953538104/ZuiControl/actions/runs/32489793335>。
- 当前 CI artifact：`D:\3.VScode\Mi\work\ci_artifacts\zuicontrol_32489793335`。
- 最终成品：`D:\3.VScode\Mi\【B刷机】072`；最终 `super.img` 反向抽取 verifier 返回 `ok=true`。
- 安全 9008 目录：`D:\3.VScode\Mi\flash\ZuiControl_9008_SAFE_072`；刷写日志：`D:\3.VScode\Mi\flash\Log\ZuiControl_qdlrs_2026-08-21_22-16-41.log`。Firehose 明确返回 `All went well! Resetting to system`，脚本随后确认 072、boot completed 和 40/0.21.3。

```text
e7e85b5cd2806b8c27adf4925e05ee169072a79a43502effc34c97fb27ee8371  boot.img
3d1702c91bcde81af31086c639ffc15b4a277d4525d2c30be5c097dc96dbd9ed  super.img
0b11807493329e46f9c94f0017608f999061ade2b952638afdb4b436ca27fb1a  vbmeta_system.img
926aa809ec55f8a521449f8673b48f93e55b412884ab23b087cc4536b73cdcce  vbmeta.img
0675617c8348a5d763bb5901b16aa5391f40a4b07a2d8c83595319dfef5fe666  ZuiControl-v19-release.apk
0675617c8348a5d763bb5901b16aa5391f40a4b07a2d8c83595319dfef5fe666  ZuiControl-v19-system.apk
```

- 最终 live `boot_a/boot_b` 都逐块哈希为用户提供的 `e7e85b...8371`，没有使用官方 A072 boot。最终 `vbmeta_system_a/b` 均为 `0b1180...fb1a`，`vbmeta_a/b` 均为 `926aa8...dcce`；后两者是在最终动态分区签名后，从用户高回滚模板重建。官方 A072 的这三张镜像没有作为刷写 payload。
- 安全流程只写 `super`、`vbmeta_system_a/b`、`boot_a/b`、`vbmeta_a/b` 七项；未写 userdata、GPT、persist、FRP、modemst 或设备唯一分区。
- 为满足官方 system AVB data 上限，只从 072 工作解包删除了 `/system/preload/QQMusic/QQMusic.apk`（180737432 bytes）；官方 A072 原包未改，最终系统没有再删除其它产品文件。
- 最终清理已删除 `work` 下可重建的 unpack/img/official、签名备份、两份 13GiB 中间 super、旧 CI 副本和本轮探针共 36 个精确目标；`work` 从约 72GiB 降到约 2.2GiB，D 盘可用空间从约 36.1GiB 恢复到约 103.5GiB。官方 A072、`072必刷镜像`、最终 B072、仓库、当前 CI、配置报告、072 验收记录、安全 9008 包和刷写日志均保留。

#### 072 实机功能结论

- P1：`zui_control` 存在；Launcher、Settings、相机的 raw/current/last 场景切换正确，目标/实际均为默认 `120/120`。`refreshOwner=system`、`daemonRefreshDisabled=true`、`displayVote=adaptiveRender`、`systemServiceAlive=true`，支持 60/90/120/144/165；普通 shell Binder 被 `caller package is not ZuiControl` 拒绝。当前没有显式 P1 profile 文件，`profileCount=1` 表示未配置场景默认 120；没有进入 FPS cap，也没有改 P1 设计。
- P2：072 官方 full `game_policy.xml`/`performanceconfig.xml` 已作为 baked baseline，非裁剪模板。两条 canonical profile 已恢复为 `com.kurogame.mingchao` 和 `bin.mt.plus.canary`。正常 `apply_performance` exact ACK 为 done，ZuiPP `6387 -> 20596`，terminal reload 为 `state=done;stableSeconds=3`。
- 当前 active 与 `/system/etc` bind 内容闭合：game 均为 `5e7d43726796c98b81a2d38ca2c44ad8d57f3bbd18f4cae763a7cf09d6e7eda2`，performance 均为 `861ee1df41eb37df1b1b554b7d8bfe63e6d79bf48ec20af196f3c6e8fac2a1d8`；两者在 PID 1 mountinfo 中均为 bind mount。
- 鸣潮仍为默认 GPU 422–903MHz、42/48C 为 500–903MHz，生成的 GPU level 分别为 `8_0_-1` / `7_0_-1`；鸣潮与 MT 条目均为 `ThermalConfig=0 0 0`。畸形 P2 请求返回 failed，profiles/game/performance 三个 hash 全部保持不变，回滚闭合。
- P3 使用用户提供的新 `AppOpt 2.2.3 eBPF`。072 内核无 BTF 时按作者实现回退 `/proc`；`AppOpt` SHA256 为 `7e6f40c868c1f8b460309bb9d352ac9b47250aeb59068469575d95751c8d7347`，`AppOpt-ebpf` 为 `acb2dcefc39b28d1b941e76b8c36fb696ac9810d94b777839eeb87a5f4f86751`。
- 用已安装测试 App `com.xmy.ap=0-1` 经正常 exact request 测试，新进程 30/30 个线程 affinity mask 均为 `0x3`；删除请求后目标被强停、服务停止、测试规则归零。新 policy 只对 `/proc` fallback 的无害目录探测加入 `dontaudit performanced domain (dir (getattr search))`，没有授予更宽权限。
- 当前三条权威鸣潮规则已逐字恢复：包 fallback `2-6`、`RenderThread=2-4`、`GameThread=7`；AppOpt 由 init 以 `u:r:performanced:s0` 运行且 PID 稳定。鸣潮目前在 072 上尚未安装，因此不能声称已验证真实鸣潮线程；daemon 的用户包校验也会在“仍未安装鸣潮却先重启设备”时停止 AppOpt 并移除 enabled flag，但不会删除三条配置。安装鸣潮后应在 ZuiControl 中重新保存/应用一次 AppOpt，随后再做真实线程验证。
- 相机：系统 `STILL_IMAGE_CAMERA` 和外部 `IMAGE_CAPTURE` 均成功；boot ID 不变，SurfaceFlinger `1654/start=391`、cameraserver `1940/start=417` 不变，tombstone `0 -> 0`，没有 `No matching frame rate modes`、DEAD_OBJECT 或相关 fatal。
- 云控删除仍闭合：`/system/etc/hosts` 为 56 bytes，SHA256 `425c3e713d5bae19b031bc8639c20c6a23e311a54647ba1824cbf45969a11ff4`；旧 cloud 脚本/runtime/log/setting/iptables chain 均不存在。旧 AsoulOpt 二进制、conf 和进程均不存在。
- 项目运行域精确 AVC 为 0，`comm="AppOpt"` AVC 为 0，全 buffer logcat 没有 ZuiControl/SurfaceFlinger/cameraserver 相关 fatal/ANR。诊断时两次直接 `adb pull /data/vendor/zui_control/...` 产生 `adbd -> zui_control_data_file search` denial，属于失败的只读诊断命令噪声；不要为它扩大策略。

#### 当前边界和最短下一步

1. 当前不是待刷状态，不要重复制作或刷写镜像。不要改 thermal conf、P1，不进入 FPS cap，不恢复 direct CPU/GPU sysfs、provider_direct、云控或旧 AsoulOpt。
2. 鸣潮和 MT 在降级清空的 `/data` 中都未安装。P1、P2 XML 事务、AppOpt 引擎、相机和系统稳定性已在 072 实机通过；只有“真实鸣潮 game-start 四段链”和三条真实鸣潮线程 mask 必须等用户安装 App 后验证，不能用测试包冒充。
3. 若安装鸣潮前不重启，当前 AppOpt 已在等待其进程；若先重启，安装后在 ZuiControl AppOpt 页重新保存/应用一次三条规则。随后从亮屏 Launcher 正常进入鸣潮，只做冷态功能观察，不主动烧到 95C。
4. 072 的 GPU/温控表现应作为新基线重新观察；187 上疑似未释放残留不直接外推到 072。本轮没有修改任何 thermal conf 或 CPU/GPU sysfs 节点。

### 0.13 2026-08-21 GPU 动态调频、隐藏温控与疑似限频残留（历史，已被 0.14 的 072 现场覆盖）

本节只覆盖 0.12 中 GPU/温控的当前现场和最短下一步；V40 发布、P1、P2 事务、AppOpt、相机、云控与 9008 结论仍以 0.12 为准。本轮没有改配置、代码或镜像，没有进入 FPS cap，也没有恢复 direct CPU/GPU sysfs。

#### 当前设备基线

- 设备仍是 `HA25HSZM`，PackageManager 为 40/0.21.3，codePath 应继续是 `ZuiControlV40`。
- 当前 P2 有两条 canonical profile：`com.kurogame.mingchao` 和 `bin.mt.plus.canary`。因此 active XML 已不再是 0.12 刷后只有鸣潮时的 hash；当前 mounted hash 为 game `75cbf2ca9dc5b6c47831e14bf9fe7b520975e3e0c52af50da84a9cf8d127a244`、performance `ab7ac1c0d1a331c0f3dccc379f0f35ff7bd02660fe23b56efc07b4133725e09f`，reload terminal 为 `state=done;oldPid=26148;newPid=28226;stableSeconds=3`。
- 鸣潮仍为默认温区 GPU 422–903MHz、42/48C 温区 500–903MHz；active XML 对应 `8_0_-1` / `7_0_-1`。这仍是 SM8650 实机证明过的正确消费方向，禁止按 `GPUMax/GPUMin` 表面名字改回 `0_8`。
- AppOpt 权威配置仍是三条鸣潮规则：包 fallback `2-6`、`RenderThread=2-4`、`GameThread=7`。

#### GPU 不是硬锁 903MHz

- KGSL governor 为 `msm-adreno-tz`，`force_clk_on/force_bus_on/force_rail_on` 均为 0。桌面空闲实际会到 231MHz；累计 `trans_stat` 已记录 1885 次切换，903/834/770/720/680/629/578/500/422/366/310/231MHz 都出现过，903MHz 累计约 95 秒。因此“游戏里经常 903”本身不是锁频证据。
- 判断必须把 `cur_freq` 与 `gpu_busy_percentage` 放在同一时间轴：903MHz 且忙碌率 80–100% 是负载跑满；903MHz 且忙碌率长期低于约 20% 才像错误锁频；忙碌率 80%以上而可用上限只有 578/422MHz 才是明确热/策略瓶颈。

#### 本轮鸣潮实测与疑似残留

- 两次亮屏正常启动都闭合 `onGameAppStart -> initGameHelper -> notifyPerfStatus 11/17 -> writeSavageMode open=1`。ZuiPP JSON 与 active XML 一致：默认 `GPUMax=8/GPUMin=0`，42/48C 为 `GPUMax=7/GPUMin=0`；P2 没有漏读。
- 第一轮高负载中 KGSL 先被限到 578MHz，随后降到 422MHz；422MHz 时 GPU 忙碌率长期 83–86%，构成真实 GPU 瓶颈。同期 CPU7/CPU2 等芯片结温出现 95C severe，`skin-msm-therm` 在 46.617C 进入 status 3，随后约 49.5C；当时 `quiet-therm` 仅约 40C、`back_temp` 约 41C，尚未触发 `gpu_0.conf` 的 quiet 44C 第一档。
- 退出后 422MHz 先恢复为 578MHz，但设备完全冷却到 `skin=33.3C / quiet=32.5C / back=32.7C / battery=31.5C`、标准 GPU cooling devices 均为 0 后，KGSL 仍为 `thermal_pwrlevel=6/max=578MHz`。再次正常游戏重入且 P2 四段链完整时也没有升回 903MHz。因此当前是“高温后限频释放滞后或其他策略残留”的真实待查项；尚不能断言由哪一服务写入，也不能靠改 XML 猜修。
- 最终现场已强停测试用鸣潮，Launcher 是最后真实场景，GPU 实际 231MHz/忙碌率约 1%，但允许上限仍为 578MHz、`thermal_pwrlevel=6`。

#### 三份文本 conf 只覆盖一部分热控

- `ThermalConfig=0` 映射 `cpu_0 + gpu_0 + battery_0`。`cpu_0` 从 quiet 40/42/44/46/48C 开始逐档限制；cluster1/2 上限依次为 2572.8/2188.8/1612.8/1075.2/499.2MHz，cluster3 为 2688/2112/1363.2/1017.6/480MHz。
- `gpu_0` 在 quiet 44/46/48/50C 分别限制 720/629/500/231MHz。本轮 422MHz 发生在 quiet 约 40C，所以不是这四条文本规则直接造成。
- `battery_0` 把 quiet 温度转换为 vendor `battery` virtual cooling state，不是直接的 CPU/GPU MHz 表。退出游戏后 state 由 12 降至 10/7 时，GPU 仍保持 578MHz，证明它不是唯一来源；没有完成作用映射前不要盲改。
- `/vendor/bin/thermal-engine-v2` 内置而非文本保存 `SS-GPU-SKIN`、`SS-GPU-SKIN-TEMP`、`SS-SKIN-GPU-LOW/HIGH`、`GPU-TSKIN-SENSOR` 等策略，并持有 `max_gpuclk` 路径。Thermal HAL 另有 skin severe 46.5C、CPU/GPU junction severe 95C 等静态阈值。修改 `cpu_0/gpu_0/battery_0` 不能解除这些更底层限制。

#### 新聊天最短下一步

1. 先只读确认本节版本、两条 P2 profile、active/system hash、三条 AppOpt 规则和当前 KGSL/温度现场；不要保存配置、改 conf 或制作镜像。
2. 记录重启前 `thermal_pwrlevel=6/max=578MHz`。征得用户当次确认后做一次正常冷机重启；开机后记录 Launcher 的 KGSL 基线，再亮屏从桌面启动鸣潮，连续采样 `cur/busy/min/max/thermal_pwrlevel`、skin/quiet/back、八个 gpuss 和 CPU junction，确认 P2 四段链后是否恢复 `thermal_pwrlevel=0/max=903MHz`。
3. 不要为了复现主动把设备烧到 95C。用户正常游戏时被动观察第一次 severe、578/422 限制和退出后的释放时间；区分“桌面默认上限”“HAL/KGSL safety cap”和“未释放残留”。
4. 在写入者和释放条件闭合前，不改三份 thermal conf。若以后只做中温实验，优先只软化 `cpu_0` 的 40/42C 两档，44C 以上、`gpu_0`、`battery_0`、skin 46.5C 与 junction 95C 先保持原样；任何改动都需独立版本和可回滚 9008 包。
5. 本轮部分探测曾让 `shell` 子进程直接读 `vendor_sysfs_kgsl`，产生少量 `shell -> vendor_sysfs_kgsl` AVC；这是诊断命令噪声，不是 ZuiControl/daemon 新回归，不要为它扩大 SELinux。

### 0.12 2026-08-21 0.21.3 P2 重入与 SM8650 GPU 索引修复（V40 已刷后验收；GPU 当前现场由 0.13 覆盖）

本节覆盖 0.11 及更早章节中的当前版本、P2 GPU 范围语义、ZuiPP/GameHelper 重入时序、成品 hash 和下一步。设备 `HA25HSZM` 已通过安全 7 项 9008 流程持久刷入 40/0.21.3/V40，并完成身份、P1、P2 可逆修改/恢复、正常游戏重入、GPU/温控、AppOpt、相机、云控删除、AVC 和稳定性验收。当前不是临时 bind 或待刷状态。

#### 当前成品与发布事实

- 生产代码 commit：`1b58816` (`fix: stabilize P2 reentry and GPU ranges`)
- GitHub Actions run：`32392494646`，结论 `success`：<https://github.com/xmy953538104/ZuiControl/actions/runs/32392494646>
- CI artifact：`D:\3.VScode\Mi\work\ci_artifacts\zuicontrol_32392494646`
- package：`com.zui.zuicontrol`；版本：40/0.21.3；system 路径：`/system/priv-app/ZuiControlV40/ZuiControl.apk`
- release 证书 SHA-256：`3fecf3a72ca0e0f24991d49e7306ef4a711711f48a66070755eb0237ecb3ed94`
- CI/payload/两个 sidecar APK SHA-256：`b8eb282485a8fb89304a64bf1f59ade9c0bbe928530e3f8021ba8f959f32537b`
- 最终刷机目录：`D:\3.VScode\Mi\【B刷机】187`
- 最终 `VerifyZuiControlFlashPackage.ps1` 反抽结论：`ok=true`
- 9008 刷后版本校验修复 commit：`5fbcfc3` (`fix: verify V40 after 9008 flash`)

```text
5fc24c5b36ba7394125b87b681b62e38575172057c78417a0fa24746815be76b  boot.img
25b8d9f0c80bed77c660200abd3cca92dff67db5549d19a0c94892d150ac6f3b  super.img
9db326d3d605885c4afdac6b0883dc3f9c0bc2b9b1b3766cc4808945015967f5  vbmeta.img
d5770041b2ae6cc5e33b139175c826545c25b1323c1303517ed17442f67e9256  vbmeta_system.img
b8eb282485a8fb89304a64bf1f59ade9c0bbe928530e3f8021ba8f959f32537b  ZuiControl-v19-system.apk
b8eb282485a8fb89304a64bf1f59ade9c0bbe928530e3f8021ba8f959f32537b  ZuiControl-v19-release.apk
```

日常更新只允许 `scripts/FlashZuiControl9008.ps1` 的安全 7 项包；不得使用原始 99 项全量 XML。每次刷写仍必须取得用户当次明确授权。

#### V40 持久刷后真实结果

- 自动刷写日志：`D:\3.VScode\Mi\flash\Log\ZuiControl_qdlrs_2026-08-21_08-38-38.log`。脚本从 Android 自动进入 `COM3/9008`，7 项全部写完，Firehose 返回 `All went well! Resetting to system`；自动复位后确认同一 serial、`boot_completed=1`、40/0.21.3 和 `/system/priv-app/ZuiControlV40`。设备 boot ID 为 `3e711fdf-cca0-48ba-96bb-9a016476591d`。
- P1：`refreshOwner=system`、`daemonRefreshDisabled=true`、`displayVote=adaptiveRender`。普通 shell Binder 被 `caller package is not ZuiControl` 拒绝；system UID 可逆设置 Settings 60Hz 后，`targetDisplayHz/actualDisplayHz=60/60`，删除测试规则回桌面后恢复 120/120，profile 最终只剩默认 120。
- 开机从保留 profile 自动重生 active XML。最终 active 与 `/system/etc` 的 game hash 均为 `15841c4c7bf11c3c9eb5773a15ff757afd46ec89eacff9dd9f3a94344806037c`，performance hash 均为 `a6788fef30dc23ea8f30527b59b4f794322d6268bc705c9cbecd1b9973290a65`，两者均为 bind mount。冷档 GPU 为 `8_0_-1`，42/48C 档为 `7_0_-1`。
- 一次真实改变 P2、再恢复原值均通过同一原子入口完成。运行中修改耗时 13.03 秒，ZuiPP `6363 -> 24450`，终态 `game=user_existing;target=stopped`；目标未运行时恢复耗时 21.35 秒，ZuiPP `24450 -> 26148`，终态 `game=user_existing;target=not_running`。两次均为 `state=done;stableSeconds=3`，最终 profile、hash、mount 已逐字恢复。
- 恢复后从亮屏桌面正常进入鸣潮，同一包在 09:02:59 闭合 `onGameAppStart -> initGameHelper -> notifyPerfStatus 11/17 -> writeSavageMode open=1`。JSON 为默认 `GPUMax=8/GPUMin=0`、42/48C `GPUMax=7/GPUMin=0`。未恢复 provider_direct。
- 冷机阶段 GPU 允许 231–903MHz，`thermal_pwrlevel=0`，连续采样可实际到 903MHz。高负载后芯片 GPU/CPU 结温曾碰到 95C，Thermal HAL status=3，KGSL 将 GPU 上限降到 578MHz、`thermal_pwrlevel=6`；当时 `back_temp` 约 43.3C、`quiet-therm` 约 42.2C、电池约 41.3C。这是独立安全温控覆盖 P2 请求，不是 XML 未读。
- AppOpt：init service running，真实模板仍为包 fallback `2-6`、`RenderThread=2-4`、`GameThread=7`。两次新鸣潮进程中 190–205 个普通线程、RenderThread、GameThread、RHI 均符合预期。少量由 GameThread 后期派生的 `APM-*`/匿名线程会继承 CPU7；临时增加显式通配符仍未纠正，说明这是原 AppOpt 二进制只在进程早期扫描的精度边界。测试后已恢复三条权威规则，没有留下无效通配符，也没有引入第二套常驻扫描器。
- 相机：连续 3 次 `STILL_IMAGE_CAMERA` 和 2 次第三方 `IMAGE_CAPTURE` 均正常；boot ID 不变，SurfaceFlinger `1670/start=401`、cameraserver `1914/start=420` 不变，无新增 tombstone、`No matching frame rate modes`、`DEAD_OBJECT` 或 fatal。
- 云控删除仍闭合：hosts 56 字节、SHA256 `425c3e713d5bae19b031bc8639c20c6a23e311a54647ba1824cbf45969a11ff4`，旧脚本/数据/setting/iptables chain 全部不存在。dmesg 与全 buffer logcat 没有项目相关 AVC；精确 fatal/NPE 审计只命中无关 Lenovo App Store `ImeiHelper`。
- 四轮稳定性观察中 boot ID、ZuiPP PID 26148、GameHelper PID 26283、AppOpt PID 和 XML/ACK 均稳定。GameHelper 在被受控停止时会打印 OEM 自身的 `IntentReceiverLeaked VolumeReceiver`，但旧进程随后按设计退出，新 GameHelper 正常预热并完成后续游戏闭环；这不是 fatal 或事务失败。

#### 根因 1：ZuiPP PID 重启了，但运行链未就绪

旧 daemon 的“成功”只保证 ZuiPP 新 PID 存活并稳定 3 秒，没有保证两个关键上层就绪：

- GameHelper 有 Console、ScreenRecorder、Rocker、Main 等多个 sticky service。ZuiPP 被杀时它们还活着，ActivityManager 会按 1/11/21 秒等间隔分批重启，容易错过游戏重入。
- 新 ZuiPP 的静态 `PerformanceConnectHelper` 在 `com.zui.pp/com.zui.performance.clientcenter.PerformanceConnect` 创建前是 null。这时即使 OEM provider 接受 mode，也会在 `sendLimitInner` 对 null 连接精确 NPE；GameHelper 只记录 `writeSavageMode open=0`，看不到 `notifyPerfStatus 11/17`。

0.21.3 的最小修复顺序是：

```text
停止 GameHelper 已知 services 并确认旧进程退出
-> 停止 ZuiPP 已知 services
-> TERM 旧 ZuiPP
-> 等待新 ZuiPP PID 稳定 3 秒
-> 显式启动 ZuiPP PerformanceConnect
-> 用 OEM GAME_MODE_START_SERVICE 预热 GameHelper，等新 PID 稳定 2 秒
-> 才发 terminal ACK done
```

App 的非取消等待框增加了对应真实阶段。没有恢复 daemon provider_direct，没有伪造游戏态。在 V39 设备上临时精确替换新 daemon 并重载后，ZuiPP `6239 -> 19239`、GameHelper 新 PID `19372`；亮屏解锁从桌面正常启动鸣潮，日志闭合：

```text
onGameAppStart(com.kurogame.mingchao)
-> GameHelper initGameHelper(com.kurogame.mingchao)
-> ZuiPP notifyPerfStatus : 11 / 17（当前 CPU/GPU JSON）
-> GameHelper writeSavageMode::open::1,status::0
```

息屏/keyguard 下用 adb 强拉 Activity 不一定产生正常 game-start；这只是错误测试条件，不是产品流程。交付路径必须是亮屏、解锁、从桌面正常启动。

#### 根因 2：SM8650 GPU 字段在实际 TAssistant 中方向相反

旧生成器将用户 GPU 422–903MHz 写为：

```xml
<Freq level="901">0_8_-1</Freq>
```

ZuiPP 日志把它解析为 `GPUMax=0, GPUMin=8`，但 SM8650 TAssistant/KGSL 的实际效果是后一个 index 变成最终可用上限。在 `quiet-therm=37.8C`、GPU thermal cooling state 均为 0 时，旧 XML 仍立即得到 `thermal_pwrlevel=8/max_gpuclk=422MHz`；所以用户看到长期 422/500MHz 不只是夏天热控，首先是我们的 XML 索引顺序错了。

可逆实验只将该值改为 `8_0_-1`，重载并正常重入游戏后，ZuiPP 得到 `GPUMax=8,GPUMin=0`，冷机无 thermal clamp 时变成 `thermal_pwrlevel=0/max_gpuclk=903MHz`，`cur_freq` 可按负载波动。随后已逐字恢复原 active XML 和 hash，没有将实验文件留在设备。

0.21.3 从 `XmlProfileGenerator` 根修正：用户 UI/API 仍是正常的 min/max，但写入 XML 时按 SM8650 实测消费方向输出 `minIndex_maxIndex_-1`。测试锁定 422–903MHz -> `8_0_-1`、500–903MHz -> `7_0_-1`。模板增加新 stamp，升级后 daemon 会从保留的 profile 自动重生 active XML，不需用户再点一次保存。

#### 温度与最终频率的权威边界

- 鸣潮当前 profile 存在三个完整温区：默认（<42C）、42C、48C，不是漏了中温/高温。UI level 8/14 通过 +34 映射为 42/48C。P2 选档看 `back_temp`（实机 thermal zone 55；zone 54 是 `front_temp`）。
- 系统 UI/dumpsys 里 41.6–42C 的“电池温度”是另一个 `battery` 传感器（zone 85），不能用它直接判断 P2 温区或 GPU 热控。
- vendor 安全链由 `thermal-engine-v2`、`vendor.lenovo.hardware.performance-service`、Qualcomm KGSL/HAL 执行，case 0 主要读 `quiet-therm`（zone 61）和各芯片结温。`/vendor/etc/thermal-engine_gpu_0.conf` 在 quiet 44/46/48/50C 分别设 GPU 720/629/500/231MHz 上限，CPU 文件从 quiet 40C 就开始逐档限制。
- `ThermalConfig=0 0 0` 只是不再切到更激进的 100/200/300 游戏 user case；case 0 本身仍组合 `cpu_0/gpu_0/battery_0`，不是关闭温控。P2 XML 是 OEM 性能请求，vendor safety thermal 可合法覆盖它。本轮不改安全温控文件。

#### App 进程、通知、P2 与 AppOpt 的真实生命周期

- 快捷通知由 `ZuiControlQuickService` 前台 service 支撑。只要通知存在，`com.zui.zuicontrol` 的轻量进程就存在；Android 不存在“App 完全没运行但自己的动态通知还能点击”的实现。该 service 只接收点击并发 Binder，不是刷新率大脑。
- 已保存 P1 由 system_server `zui_control` 执行；P2 由 bind XML + ZuiPP/TAssistant/GameHelper + `zui_controld` 执行；AppOpt 由 init 管理的 `/system/bin/AppOpt -c /data/vendor/zui_control/appopt/applist.conf -s 2` 原生服务执行。三者都不需要 MainActivity 常驻。
- 如果强停 ZuiControl，快捷通知会消失，直到重开 App/重启时 receiver 恢复；但已持久的 P1 profile、active XML/P2 和 AppOpt 规则仍生效。只有编辑配置和点快捷通知需要 App 进程短暂参与。
- 保存 P2/AppOpt 后，daemon 只在目标当时有 PID 时自动 force-stop；未运行则是可预期 no-op。用户不需去系统设置手动强停。

#### V40 后续回归要点

1. 确认 PackageManager 仍为 40/0.21.3，codePath 为 `ZuiControlV40`，旧 V39 不存在。
2. 确认 P1、P2 鸣潮 profile 和 AppOpt 三条规则与用户当前选择一致；P1 owner 仍为 system，daemon refresh disabled，不进入 FPS cap。
3. 开机 daemon 应因新模板 stamp 自动重生 XML；active/system 两对 hash 闭合且为 bind mount。鸣潮默认档 422–903MHz 的 GPU Freq 必须是 `8_0_-1`，42/48C 档 500–903MHz 必须是 `7_0_-1`。
4. ZuiPP 已运行时，reload terminal 必须 `state=done`，新 PP PID 稳定 3 秒，PerformanceConnect 启动，GameHelper 新 PID 稳定 2 秒；任一 `stop_game_helper/performance_connect/prewarm_game_helper` error 都不能当成成功。
5. 亮屏、解锁、从桌面正常启动鸣潮，必须闭合同一 package 的 `onGameAppStart -> initGameHelper -> notifyPerfStatus 11/17 -> writeSavageMode open=1`；不得用 provider rows 或单独 PID 代替。
6. 在 `quiet-therm <44C`且 GPU thermal cooling state=0 的冷机条件下，默认档应看到 `thermal_pwrlevel=0/max_gpuclk=903MHz`，实时频率可按负载波动。若 quiet 已达 44/46/48/50C，分别被安全热控限制到 720/629/500/231MHz 是合法结果，要同时记录 battery/back/quiet，不可只报电池温度。
7. 复验 AppOpt 真实线程 mask、P1、相机 PID/starttime/tombstone、云控完全删除状态，并同时查 dmesg 与 logcat all buffers 的项目 AVC/fatal/ANR。

### 0.11 2026-08-20 0.21.2 UI 收口、连续核心范围与 V39 刷后验收（历史，已被 0.12 覆盖）

本节覆盖 0.10 及更早章节中的当前版本、UI、AppOpt 取值范围、成品 hash 和下一步。设备 `HA25HSZM` 已由正常 Android 自动进入 `COM3/9008`，使用安全 7 项 XML 持久刷入 `versionCode=39` / `versionName=0.21.2`，再完成真实横竖屏、P1、P2、AppOpt、相机、云控删除和稳定性验收。当前运行的是 `/system/priv-app/ZuiControlV39/ZuiControl.apk`，不是临时 bind APK。

#### 当前成品与发布事实

- 生产代码 commit：`402b20c6e85a769587853f5195510ac0558f6f09`
- GitHub Actions run：`32357568579`，结论 `success`：<https://github.com/xmy953538104/ZuiControl/actions/runs/32357568579>
- CI artifact：`D:\3.VScode\Mi\work\release_0.21.2_run_32357568579`
- package：`com.zui.zuicontrol`；版本：39/0.21.2；system 路径：`/system/priv-app/ZuiControlV39/ZuiControl.apk`
- release 证书 SHA-256：`3fecf3a72ca0e0f24991d49e7306ef4a711711f48a66070755eb0237ecb3ed94`
- CI、payload、system 内嵌和两个 sidecar APK SHA-256：`68eece15d4c2e3ca14d4d9a9669a196ab48b913ac870a53eeac981117ee3c19e`
- 最终刷机目录：`D:\3.VScode\Mi\【B刷机】187`
- 安全自动刷机目录：`D:\3.VScode\Mi\flash\ZuiControl_9008_SAFE`
- 最终 super 反抽 verifier：`ok=true`

```text
5fc24c5b36ba7394125b87b681b62e38575172057c78417a0fa24746815be76b  boot.img
e8980048c291eb7e33eb4b70875a00ab2dc680e1db86f016c7137ea826d58648  super.img
9db326d3d605885c4afdac6b0883dc3f9c0bc2b9b1b3766cc4808945015967f5  vbmeta.img
15d61f36eb6feeb1b0f0df09d71b8540c1c2f274df71e112cd1adad59dfeb593  vbmeta_system.img
68eece15d4c2e3ca14d4d9a9669a196ab48b913ac870a53eeac981117ee3c19e  ZuiControl-v19-system.apk
68eece15d4c2e3ca14d4d9a9669a196ab48b913ac870a53eeac981117ee3c19e  ZuiControl-v19-release.apk
```

自动刷写日志：`D:\3.VScode\Mi\flash\Log\ZuiControl_qdlrs_2026-08-20_18-25-38.log`。日志确认 super 13 GiB 和另外 6 项全部写到 100%，终态为 `All went well! Resetting to system`；脚本自动复位后确认同一 serial、`boot_completed=1`、39/0.21.2 和 V39。日常更新仍禁止使用原始 99 项全量 XML。

#### 0.21.2 UI 与 AppOpt 收口

- 继续使用原生 Kotlin + Android Views，没有引入 Compose、Rust UI 或新依赖。右上刷新改为单箭头圆形图标；刷新率一级入口使用独立仪表图标，避免与刷新按钮混淆。
- 刷新率卡片统一为“App 图标 + 名称 + Hz”横排；竖屏两列、横屏三列；120Hz 不再显示“默认”前缀。新增/编辑、性能编辑、AppOpt 编辑、加载等待和选择托盘统一圆角、间距与主色按钮。
- 设置页去掉额外白色外层容器，四项工具直接放在页面背景上：每项同高、同宽、同圆角、同 8dp 间距，图标/标题/副标题/箭头基线一致，不再出现灰底套白底再套灰卡。
- 横屏仍为左侧居中 navigation rail，竖屏仍为底部居中三项导航；设置只在右上角。持久 V39 实机截图位于 `D:\3.VScode\Mi\work\device_v39_release`，重点为 `home_landscape_v39.png`、`settings_landscape_v39.png`、`settings_portrait_v39.png`。
- AppOpt 整包自定义不再只给四个固定预设；UI 可点选 0..7 的连续单核或 `X-Y` 范围，daemon 仍严格拒绝倒序、断续、越界和类似 `01` 的歧义输入。8 Gen 3 线程模板继续优先，整包规则只作 fallback。

#### V39 持久刷后真实结果

- P1：`zui_control` 存在，`refreshOwner=system`、`daemonRefreshDisabled=true`、`displayVote=adaptiveRender`；普通 shell Binder 得到 `caller package is not ZuiControl`。原 profile 逐字保留：桌面 144、鸣潮 60、MT 90、未配置默认 120，且没有 SystemUI 条目。六轮 Settings 120/120、MT 90/90、相机切换全部成功。这里仍是 adaptive render vote，不是 FPS cap；静止画面允许物理临时降档。
- P2：原鸣潮 v4 profile 保留；`xml_state=mounted`。active 与 `/system/etc` 的 game hash 都为 `cf787905a1a2d9a3afae69b7a48272ff0d86ff0e35c99d9a305e3dc31b634c1d`，performance hash 都为 `447277c22ba0d2cd378b05e2c99bc80d89d4fb57717deb78ac5ca760407e7a92`，两者均为 bind mount。开机 ZuiPP `4713 -> 6409`，终态 `state=done;reason=boot_active;stableSeconds=3`。
- 亮屏强停后从桌面重入鸣潮，日志闭合：同包名 `onGameAppStart` -> GameHelper `initGameHelper` -> ZuiPP `notifyPerfStatus : 11 17`（值与 XML 四簇 CPU/三温区 GPU 一致）-> `writeSavageMode::open::1,status::0`。没有恢复旧 provider_direct。
- AppOpt：`init.svc.zui_appopt=running`，PID 7271，SELinux 域为 `u:r:performanced:s0`，三条鸣潮规则保留。鸣潮 PID 15971 的真实 `/proc` 结果：`RenderThread` 为 `2-4`；所有精确 `GameThread` 为 `7`；TaskGraph、RHI 等未单独匹配线程按包 fallback 为 `2-6`。这证明规则作用于真实线程，而非只写配置。
- 相机：`STILL_IMAGE_CAMERA` 和第三方 `IMAGE_CAPTURE` 都成功。整个测试 boot ID 不变；SurfaceFlinger PID/starttime 为 `1630/387`，cameraserver 为 `1928/414`，六轮重复相机切换仍不变，tombstone 列表无新增。主动 force-stop 相机客户端时出现一次 Java client binderDied，属于预期客户端断开，不是 cameraserver 死亡。
- 云控保持完全删除：hosts 为 56 字节且 SHA-256 为 `425c3e713d5bae19b031bc8639c20c6a23e311a54647ba1824cbf45969a11ff4`；旧脚本、runtime、log、setting 和 iptables/ip6tables 链均不存在。
- 没有包含 `zui_control`、daemon、AppOpt 或两份 XML 路径的项目 AVC。系统仍有原生 system_server 通用 denial，以及 cameraserver 读取 `vendor_display_prop` 的 denial；相机多轮运行没有 PID 变化、tombstone 或重启，因此不能把这些原厂噪声误判成 ZuiControl 回归，也不能为其盲目扩大权限。

#### 当前操作与新聊天最短路径

1. 刷新率：右下 `+` 添加用户 App，卡片直接编辑；未配置默认 120。通知/QS 仅用于快速修改上一个真实场景。
2. 性能：右下 `+` 选择 App 并设置各温区 CPU/GPU。保存后 daemon 自动校验、事务化 XML、同步 Game Assistant、重启 ZuiPP，并只在目标正在运行时自动强停；完成后从桌面重开目标。
3. AppOpt：优先选择“8 Gen 3 优化”；整包自定义时点亮连续的起止核心。保存后 daemon 自动重启 AppOpt，并只在受影响目标正在运行时自动强停；完成后重开目标。
4. 设置：右上齿轮进入。导入/导出文件只是交换副本，权威源仍是 `/data/vendor/zui_control/appopt/applist.conf`。
5. 新聊天先只读确认 39/0.21.2、V39、P1 owner、P2 hash/mount/reload 和三条 AppOpt 规则；只有可复现新缺陷才制作下一包。不要进入 FPS cap，不改 P1，不恢复 direct CPU/GPU sysfs、provider_direct、云控或旧 AsoulOpt。

### 0.10 2026-08-20 0.21.1 响应式 UI、同值秒回与 V38 刷后验收（历史，已被 0.11 覆盖）

本节覆盖 0.9 及更早章节中的当前版本、UI 布局、同值保存时长、成品 hash 和下一步。设备 `HA25HSZM` 已从正常 Android 自动进入 COM3/9008，经安全 7 项 XML 持久刷入 `versionCode=38` / `versionName=0.21.1`，随后完成真实横竖屏、P1、P2、AppOpt、相机、云控删除状态和项目 AVC 验收。当前运行的是 `/system` 内 V38，不是临时 bind APK。

#### 当前成品与发布事实

- 生产代码 commit：`84f3c97bf27f0cec7c8335aa0d164baf49e2b376`
- GitHub Actions run：`32330351987`，结论 `success`：<https://github.com/xmy953538104/ZuiControl/actions/runs/32330351987>
- CI artifact：`D:\3.VScode\Mi\work\release_0.21.1_run_32330351987`
- package：`com.zui.zuicontrol`；版本：38/0.21.1；system 路径：`/system/priv-app/ZuiControlV38/ZuiControl.apk`
- release 证书 SHA-256：`3fecf3a72ca0e0f24991d49e7306ef4a711711f48a66070755eb0237ecb3ed94`
- CI、payload、system 内嵌和两个 sidecar APK SHA-256：`5780bda644ce920c6072d6fa73f9dde486cc58f4037aba5ba271da0a38496d62`
- 最终刷机目录：`D:\3.VScode\Mi\【B刷机】187`
- 安全自动刷机目录：`D:\3.VScode\Mi\flash\ZuiControl_9008_SAFE`
- 最终 super 反抽 verifier：`ok=true`

```text
5fc24c5b36ba7394125b87b681b62e38575172057c78417a0fa24746815be76b  boot.img
eaa6e5ea230fdff34fe2935a3ffe3d63c61521ed22826ce93a82cf7c8055cbce  super.img
9db326d3d605885c4afdac6b0883dc3f9c0bc2b9b1b3766cc4808945015967f5  vbmeta.img
92e205e3d9571c3a42d376d7bf7b05f86e0897813f6c2b08abbe1084c71cf825  vbmeta_system.img
5780bda644ce920c6072d6fa73f9dde486cc58f4037aba5ba271da0a38496d62  ZuiControl-v19-system.apk
5780bda644ce920c6072d6fa73f9dde486cc58f4037aba5ba271da0a38496d62  ZuiControl-v19-release.apk
```

自动刷写日志：`D:\3.VScode\Mi\flash\Log\ZuiControl_qdlrs_2026-08-20_12-19-00.log`。脚本只写 super、boot_a/b、vbmeta_a/b、vbmeta_system_a/b，Firehose 返回 `All went well! Resetting to system`，自动复位后确认同一 ADB serial、`boot_completed=1` 和 38/0.21.1。禁止使用原始 99 项全量 XML 做日常更新。

#### 0.21.1 UI 与响应改动

- 仍使用原生 Kotlin + Android Views，不引入 Compose、Rust UI 或新依赖。右上刷新和设置改为图标真正居中的圆形 `ImageView` 按钮，选中状态也在同一底图内，不再出现图标与底图分离。
- 竖屏是底部居中的刷新率/性能/AppOpt 三项导航；横屏是左侧居中的纵向 navigation rail。设置只保留在右上角。选中胶囊完整包住图标和文字，三个一级入口不再横竖屏都挤在顶部。
- 刷新率主页只保留 App、图标和 Hz；右下角 `+` 新增，点卡片编辑。性能主页只保留配置列表，点卡片进入二级编辑。AppOpt 主页只保留规则列表，优先提供内置 8 Gen 3 细分线程模板和整包 fallback。所有主功能卡片、弹窗、托盘、圆角、间距和字体统一。
- 真机截图：`D:\3.VScode\Mi\work\device_v38_release\zui_v38_portrait.png`、`zui_v38_landscape3.png`、`zui_v38_settings.png`。横屏截图实际为 `2560x1600`、`ROTATION_90`，不是把竖屏截图误当横屏。
- P2/AppOpt 在发送前比较 canonical 配置：保存内容完全相同则本地直接返回，不写 Settings 请求槽、不重启 ZuiPP/AppOpt、不停止目标。实机同值操作小于 1 秒，ACK 保持不变。
- 真正改变 XML 的 P2 实测约 11.7–13.1 秒；真正改变 AppOpt 的实测约 9.2–10.9 秒。等待框显示真实阶段，只在 exact terminal ACK 后关闭。

#### V38 持久刷后真实结果

- P1：`refreshOwner=system`、`daemonRefreshDisabled=true`、`displayVote=adaptiveRender`，普通 shell Binder 被拒绝。鸣潮 profile 目标/实际为 60/60，桌面最终为 144/144，未出现 `lastError`，profile 文件没有 SystemUI。没有修改 P1，也没有进入 FPS cap。
- P1 的准确产品边界仍应保留：这里是系统 adaptive render vote，不是 UID FPS cap；静止的 Settings/相机页面可在目标 120 时物理降至 30/60，发生交互或回到配置场景后再升档。不能把 `targetDisplayHz` 描述成任何时刻都不允许物理降档的硬定频。
- P2：开机后 `xml_state=mounted`，ZuiPP `4804 -> 6656`，终态 `state=done;reason=boot_active;stableSeconds=3`。active 与 `/system/etc` 的 game hash 都为 `cf787905a1a2d9a3afae69b7a48272ff0d86ff0e35c99d9a305e3dc31b634c1d`，performance hash 都为 `447277c22ba0d2cd378b05e2c99bc80d89d4fb57717deb78ac5ca760407e7a92`，两者均为 bind mount。
- 亮屏强停并从桌面重新进入鸣潮，真实日志闭合：同包名 `onGameAppStart` -> GameHelper `initGameHelper` -> ZuiPP `notifyPerfStatus : 11 17`（三温区 CPU/GPU JSON）-> `writeSavageMode::open::1,status::0`。这证明原厂 GameHelper/ZuiPP 读取了生成 XML；没有恢复旧 provider_direct。
- AppOpt：权威配置保留三条鸣潮规则，service 为 running。新鸣潮 PID 17020 的主进程实际 mask `7c`（CPU2-6），`RenderThread` mask `1c`（CPU2-4），所有精确 `GameThread` mask `80`（CPU7）。这是 `/proc`/`taskset` 的内核结果，不只是 UI 或配置文本。
- P2 与 AppOpt 互补：P2 约束原厂对各 CPU cluster/GPU 的性能请求，AppOpt 限制具体线程允许在哪些 CPU 运行。错误或过激参数仍会共同造成卡顿；XML 上下限是 OEM 请求，不是不可被更高优先级 thermal 覆盖的 hard cap。
- 相机：`STILL_IMAGE_CAMERA` 冷启动和第三方 `IMAGE_CAPTURE` 热启动均成功。SurfaceFlinger 始终 PID/starttime `1647/387`，cameraserver 始终 `1940/413`，tombstone 列表未变化，没有 frame-rate fatal、abort、DEAD_OBJECT 或设备重启。
- 云控继续完全删除：`/system/etc/hosts` 为 56 字节、SHA-256 `425c3e713d5bae19b031bc8639c20c6a23e311a54647ba1824cbf45969a11ff4`；旧脚本、runtime 目录、setting 和 iptables/ip6tables 链均不存在。
- dmesg 与全 buffer logcat 按项目路径筛选没有相关 AVC、fatal 或 ANR。鸣潮自身尝试 netlink 的 `untrusted_app_32` denial 与 ZuiControl 无关，禁止为它扩大项目策略。

#### 当前操作方法

1. 刷新率：进入“刷新率”，右下 `+` 选择用户 App 和 Hz；已有条目直接点卡片修改或删除。120 是未配置默认值。通知/QS 只在需要快速改上一个真实场景时使用。
2. 性能：进入“性能”，右下 `+` 选择 App，配置默认/温区 CPU 四簇与 GPU 上下限后保存。ZuiControl 会单向加入 Game Assistant、自行生成/校验/promote/bind XML、重启 ZuiPP，并仅在目标正在运行时自动强停；完成后从桌面重新打开目标。当前三种 OEM mode 镜像同一份配置，切换均不会绕过用户值。
3. AppOpt：进入“AppOpt”，右下 `+` 选择用户 App，优先使用“8 Gen 3 细分线程模板”，没有可靠线程模板时才用整包 fallback。保存会严格校验并自动停止运行中的目标；完成后重新打开。备份导入/导出在右上设置页，`Download/ZuiControl/AppOpt.conf` 只是交换副本，权威源仍在 `/data/vendor/zui_control/appopt/applist.conf`。
4. 设置：右上齿轮进入健康状态、日志、AppOpt 导入/导出和停止服务。右上刷新只刷新 UI 状态，不负责维持核心功能。

#### 新聊天当前最短下一步

1. 先只读确认设备仍为 38/0.21.1、V38、P1 owner、鸣潮 P2 hash/mount、ZuiPP 终态和三条 AppOpt 规则；不要无原因重复修改配置或重新刷包。
2. 用户若报告 UI 问题，先取得真实横/竖屏截图和当前 rotation/window bounds，再针对现有 Views 做最小调整；不要换 Compose/Rust。
3. 用户若报告 P2 不响应，收集 exact ACK、Game Assistant membership、profile、active/system hash、reload 和下一次真实 `onGameAppStart -> GameHelper -> notifyPerfStatus -> writeSavageMode`。
4. 用户若报告 AppOpt 不响应，重启目标后读取精确线程名及 `/proc/<tid>/status`/`taskset`；不要只看配置文本。
5. 只有出现可复现的新缺陷才制作下一包。仍不进入 FPS cap，不改 P1，不恢复 direct CPU/GPU sysfs、provider_direct、云控或旧 AsoulOpt；自动刷机只能使用 7 项安全包。

### 0.9 2026-08-20 0.21.0 统一 UI、线程级 AppOpt 与最终刷后验收（历史，已被 0.10 覆盖）

本节覆盖 0.8 及更早章节中的当前版本、AppOpt 只支持整包预设、最终基线和下一步。设备 `HA25HSZM` 已通过安全 7 项 9008 流程持久刷入 `versionCode=37` / `versionName=0.21.0`，随后完成正常重启、真实亮屏游戏重入、内核线程亲和、相机、P1、P2、AppOpt、SELinux 和连续稳定性验收。当前成品不是临时 bind 或待刷包。

#### 当前成品与发布事实

- 生产 commit：`36d6b26c05e5c0ecfca04ae78120aede51f1d8a2`
- GitHub Actions run：`32266515192`，结论 `success`：<https://github.com/xmy953538104/ZuiControl/actions/runs/32266515192>
- CI artifact：`D:\3.VScode\Mi\work\release_0.21.0_run_32266515192`
- package：`com.zui.zuicontrol`；版本：37/0.21.0；system 路径：`/system/priv-app/ZuiControlV37/ZuiControl.apk`
- release 证书 SHA-256：`3fecf3a72ca0e0f24991d49e7306ef4a711711f48a66070755eb0237ecb3ed94`
- CI、payload、system 内嵌和两个 sidecar APK SHA-256：`459db275dd33272ed229ac4a7adfac180f314d3345dca4c30d4b9f37b7fe7fef`
- 最终刷机目录：`D:\3.VScode\Mi\【B刷机】187`
- 安全自动刷机目录：`D:\3.VScode\Mi\flash\ZuiControl_9008_SAFE`
- 最终成品反抽 verifier：`ok=true`

```text
5fc24c5b36ba7394125b87b681b62e38575172057c78417a0fa24746815be76b  boot.img
b43375c2c3c53ae5df8f23f6f658ae97cc7b76b5501012fec93cf1c60db173ae  super.img
9db326d3d605885c4afdac6b0883dc3f9c0bc2b9b1b3766cc4808945015967f5  vbmeta.img
fc3efa5dcb96406d211362a348f5ba775961b2c2af960c6290e26e5a5c827559  vbmeta_system.img
459db275dd33272ed229ac4a7adfac180f314d3345dca4c30d4b9f37b7fe7fef  ZuiControl-v19-system.apk
459db275dd33272ed229ac4a7adfac180f314d3345dca4c30d4b9f37b7fe7fef  ZuiControl-v19-release.apk
```

自动刷写日志：`D:\3.VScode\Mi\flash\Log\ZuiControl_qdlrs_2026-08-19_23-25-02.log`。脚本从正常 Android 自动进入 COM3/9008，只写 super、boot_a/b、vbmeta_a/b、vbmeta_system_a/b，Firehose 返回 `All went well!`，自动复位后确认同一 ADB serial、`boot_completed=1` 和 37/0.21.0。禁止使用原始 99 项全量 XML 做日常更新。

#### 0.21.0 当前产品与 UI

- App 仍是原生 Kotlin + Android Views，没有引入 Compose、Rust UI 或新运行时依赖。四个主页面、卡片、按钮、间距、标题、状态和进度框已统一；横竖屏及小窗口均真实截图检查。这样比重写技术栈更轻、更容易随 ROM 内置维护。
- P1 刷新率页保留 system_server 唯一 owner；P2 性能页负责 XML/游戏助手；AppOpt 页负责线程亲和；系统页负责健康状态、日志与导入导出。各页不再混用大小不一的按钮和杂乱分隔线。
- P2 与 AppOpt 长操作都显示不可取消的真实阶段进度框，只在 exact requestId、exact command 的 terminal ACK 后关闭；Activity 重建不会覆盖正在执行的单槽请求。

#### P2 当前语义与 V37 实测

- P2 添加/删除继续严格单向同步 Game Assistant 自定义列表：ZuiControl 新增则同步添加，ZuiControl 删除则同步移出；Game Assistant 自己的增删不反向改 ZuiControl。membership、profile、active XML、mount/reload 和终态 ACK 是一笔可回滚事务。
- 保存/删除后只在目标确实运行时自动 `force-stop`；未运行返回 `target=not_running`。用户不需要进系统设置手动强停。ZuiPP 重载也完全由 daemon 处理，用户不手动操作。
- 输入导致 XML hash 改变时，daemon 安全停止四个原厂 service、重启 ZuiPP 并观察新 PID 稳定 3 秒；输入未改变最终 XML 时允许 `skipped;same_hash`，不做无意义重启。V37 对鸣潮同值保存的直接请求约 8.9 秒，真实 UI 操作约 9.8 秒；改 hash 的操作仍需加上受控重启和 3 秒稳定窗，通常约 12–15 秒。
- 正常重启后，boot bind 使 ZuiPP `4620 -> 6636`，终态 `state=done;reason=boot_active;stableSeconds=3`。亮屏从桌面重入鸣潮后，日志依次出现同包名 `onGameAppStart`、GameHelper `initGameHelper`、ZuiPP `notifyPerfStatus : 11 17` 和 `writeSavageMode::open::1,status::0`；三档 JSON 与当前 XML 的四簇 CPU/GPU 值一致。
- 息屏时用 adb/monkey 拉进程只能证明 Activity/进程存在，系统任务为 `isSleeping=true` 时不会产生正常 Game Assistant 游戏态；这不是用户正常入口，也不能作为 P2 成功证据。亮屏从桌面启动才是交付路径。
- 最终只保留鸣潮 profile。active/system game hash 均为 `cf787905a1a2d9a3afae69b7a48272ff0d86ff0e35c99d9a305e3dc31b634c1d`，performance hash 均为 `447277c22ba0d2cd378b05e2c99bc80d89d4fb57717deb78ac5ca760407e7a92`，两处均为 bind mount。鸣潮 `ThermalConfig=0 0 0`、三个 LimitConfig 段相同，四簇共享 CPU level ID 且四个 Type 都存在。

#### AppOpt 当前语义与 V37 实测

- AppOpt 现在支持包级 fallback 加精确线程名规则，不再只能把整个包放到一组 CPU。内置 8 Gen 3 目录来自用户提供的 AsoulOpt 配置，共 326 个 package、1205 条规则，其中 879 条为线程规则；目录仅用于给用户选择目标 App 后生成模板，不会启动时全量扫描目标进程，因此数量不会造成明显运行时开销。
- 鸣潮当前模板和最终权威配置为：

```text
com.kurogame.mingchao=2-6
com.kurogame.mingchao{RenderThread}=2-4
com.kurogame.mingchao{GameThread}=7
```

- fallback 是必填安全网；线程名采用精确匹配。实机重开鸣潮后，主进程/未命中线程为 `2-6`，`RenderThread` 为 `2-4`，所有 `GameThread` 为 `7`。这证明当前 AppOpt 真正操作了内核 `Cpus_allowed_list`，不是只把文本写进配置。
- UI 支持选 App、选择内置模板、预览确认、单项修改/删除、完整文本编辑、严格校验并应用，以及 `Download/ZuiControl/AppOpt.conf` 导入/导出。自由文本也必须通过同一 parser：仅用户 App、必须有 fallback、拒绝重复项/非法 CPU 集合，整表上限 16 KiB；通过后才原子替换权威 `/data/vendor/zui_control/appopt/applist.conf`。
- 运行中应用模板实测约 9.8–11.35 秒，终态 `rules=3;stoppedApps=1;stopFailed=0`；目标未运行时约 11.5 秒，终态 `stoppedApps=0`。导入同一配置约 9.3 秒。daemon 自动停止受影响的运行中 App，并重启 AppOpt；用户完成后重新打开目标即可。
- P2 CPU 上下限与 AppOpt 线程亲和是互补关系：前者限制 OEM 对各 CPU cluster 的性能请求，后者决定线程允许落在哪些 CPU。它们不直接互相覆盖，但过窄亲和、过低频率上限或错误线程名都可能造成卡顿，模板不能被当作所有版本通用的绝对最优值。

#### 最终刷后回归与已知边界

- P1：普通 shell Binder 被拒绝；Settings 可逆 60Hz/144Hz 规则的 target、actual 和 active mode 都正确，清理测试规则后 profile 逐字恢复为默认 120，QS 未学习 SystemUI。最终 Launcher 为 `targetDisplayHz=120` / `actualDisplayHz=120`、`refreshOwner=system`、`daemonRefreshDisabled=true`。没有修改 P1，也没有进入 FPS cap。
- P1 仍保留一个需要以后单独处理的边界：本轮较早曾在相机/时钟临时场景后观察到一次 `target=120`、`actual=60` 且 focus 事件 `skipSame`，显式 refreshNow 恢复；最终重启后的相机回归没有复现并正常回到 120/120。因本轮明确禁止改 P1，不能把这个低频边界写成已修复。
- 相机在持久镜像和正常重启后重复通过 `STILL_IMAGE_CAMERA` 与第三方 `IMAGE_CAPTURE`：boot ID 不变，SurfaceFlinger `1655:390`、cameraserver `1954:420` 的 PID/starttime 均不变，tombstone 无新增，没有 `No matching frame rate modes`、DEAD_OBJECT、Fatal 或系统重启。
- dmesg 与全 buffer logcat 中按 `zui_control`、`zui_controld`、`AppOpt`、`performanced` 和 `com.zui.zuicontrol` 精确筛选的 AVC 均为 0；没有相关 fatal/ANR。原厂相机/HAL 的历史 denial 不应通过扩大项目策略来消日志。
- 重启后第一次过早读取 AppOpt 健康 setting 曾短暂看到上次 PID，20 秒周期内自动纠正为真实 PID 7273；service 和亲和执行未中断。这是状态镜像短暂滞后，不是功能失败，暂不为几秒显示延迟增加启动同步复杂度。
- 12 轮、每轮间隔 45 秒的最终观察中，boot ID 不变，daemon 始终 running，ZuiPP 始终 PID 6636，AppOpt 始终 PID 7273，P1 始终 120/120，两处 mount 始终存在，四个 active/system hash 始终逐字一致。
- 云控继续为完全删除状态。FPS cap 仍未交付；用户当前讨论的是 displayHz、P2 XML 和 AppOpt，并没有提出必须实现 UID FPS cap。CPU/GPU XML 是 OEM 性能请求而非不可覆盖 hard cap，高温或更高优先级厂商策略仍可能改变最终节点。

#### 新聊天当前最短下一步

1. 先只读确认设备仍为 37/0.21.0、V37、P1 owner、当前鸣潮 P2 profile 和三条 AppOpt 规则；不要无原因重复全套写入测试。
2. 用户若报告 P2 不响应，记录 exact ACK 最后阶段、Game Assistant membership、profile、active/system hash、ZuiPP reload 和下一次亮屏真实 `onGameAppStart`；不要只看瞬时 CPU/GPU 节点。
3. 用户若报告 AppOpt 不响应，记录 exact ACK、权威配置、AppOpt PID/service 和新启动目标的实际线程名及 `/proc/<tid>/status`；先判断线程名是否精确匹配，再调整模板。
4. 只有出现可复现的新缺陷才制作下一包。仍不进入 FPS cap，不改 P1，不恢复 direct CPU/GPU sysfs、provider_direct、云控或旧 AsoulOpt。

### 0.8 2026-08-19 0.20.7 真单向同步、内置编辑器、进度反馈（历史，已被 0.9 覆盖）

本节覆盖 0.7 及更早章节中的当前版本、P2 删除不移出游戏助手、AppOpt 必须先导出再编辑、操作期间只能等待等表述。设备 `HA25HSZM` 已通过安全 7 项 9008 流程持久刷入 `versionCode=36` / `versionName=0.20.7`；发布、自动刷写和刷后可逆实测均已闭合，设备最终恢复到原有鸣潮 P2 profile、AppOpt 0 规则的基线。

#### 当前成品与发布事实

- 生产 commit：`0d4b75c32496ce8767c0421c13bdc56b0045f63c`
- GitHub Actions run：`32218280953`，结论 `success`：<https://github.com/xmy953538104/ZuiControl/actions/runs/32218280953>
- CI artifact：`D:\3.VScode\Mi\work\release_0207_32218280953`
- package：`com.zui.zuicontrol`；版本：36/0.20.7；system 路径：`/system/priv-app/ZuiControlV36/ZuiControl.apk`
- release 证书 SHA-256：`3fecf3a72ca0e0f24991d49e7306ef4a711711f48a66070755eb0237ecb3ed94`
- CI、payload、system 内嵌和两个 sidecar APK SHA-256：`07a715c59730fabc2a09ab258c1eff5121da1b7719184970814661d1735de09f`
- 最终刷机目录：`D:\3.VScode\Mi\【B刷机】187`
- 安全自动刷机目录：`D:\3.VScode\Mi\flash\ZuiControl_9008_SAFE`
- 最终成品反抽 verifier：`ok=true`

```text
5fc24c5b36ba7394125b87b681b62e38575172057c78417a0fa24746815be76b  boot.img
93f5e7dffb76b06b725962b7c6a8d7d788c558992d47f7ea511255c4f3c54515  super.img
9db326d3d605885c4afdac6b0883dc3f9c0bc2b9b1b3766cc4808945015967f5  vbmeta.img
4635484b6469fe4db9fb9c78aa5a5f2c410aef514eda0db7b3f34d5ece053a9f  vbmeta_system.img
07a715c59730fabc2a09ab258c1eff5121da1b7719184970814661d1735de09f  ZuiControl-v19-system.apk
07a715c59730fabc2a09ab258c1eff5121da1b7719184970814661d1735de09f  ZuiControl-v19-release.apk
```

自动刷写日志：`D:\3.VScode\Mi\flash\Log\ZuiControl_qdlrs_2026-08-19_13-26-33.log`。脚本从正常 Android 自动进入 COM3/9008，只写 super、boot_a/b、vbmeta_a/b、vbmeta_system_a/b，自动复位并确认同一 ADB serial、`boot_completed=1` 和 36/0.20.7。禁止使用原始 99 项全量 XML 做日常更新。

#### 0.20.7 当前用户语义

P2：

- ZuiPP 重启完全由 ZuiControl 的 daemon 自动完成。保存或删除时，daemon 会生成和校验 XML、promote/bind、先停止四个已知原厂 service、受控重启 ZuiPP、确认新 PID 稳定 3 秒，再发布完成；用户不应手动重启 ZuiPP。
- 现在是严格的单向镜像：在 ZuiControl 新增 P2 profile，会同步添加目标到 Game Assistant 自定义列表；在 ZuiControl 删除该 profile，会同步删除由自定义列表表示的目标；在 Game Assistant 单独新增或删除，不会反向创建或删除 ZuiControl profile。系统内建游戏识别不是“自定义条目”，不能也不需要伪造删除。
- Game Assistant membership、profile、active XML 和 runtime 位于同一事务提交边界。任一步失败都恢复旧 membership/profile/XML/runtime，不允许出现“游戏列表改了但 XML 没改”或反过来的半成功。
- 保存或删除成功后，只在目标当时有运行进程时自动 `force-stop`；未运行时返回 `target=not_running`，不做无意义操作。完成后用户直接从桌面重新打开即可。
- 实机新增 `com.xmy.ap` 用时 14.766 秒，逐阶段看到 validating、generating_xml、reloading_zuipp、stopping_zuipp_services、waiting_zuipp、syncing_game_assistant、committing、stopping_target，终态 `game=user_added;target=not_running`。运行该 App 后删除 profile 用时 12.788 秒，终态 `game=user_removed;target=stopped`；membership=false、profile 消失、目标 PID 消失，XML hash 逐字恢复，ZuiPP PID 15754→23762 且稳定 3 秒。

AppOpt：

- 系统状态页现在有“编辑配置清单”：打开原生多行编辑器，内容预填当前 canonical 配置；点击“校验并应用”后，只有全部行通过校验才一次性替换权威配置。错误会留在编辑器中并明确显示，不会部分应用。
- 每条活动规则仍严格为 `普通用户包名=预设`，预设仅 `0-7`、`0-4`、`5-7`、`0-1`；不开放系统 App、线程名或任意 CPU 集合。已有的单 App 图形化添加/修改/删除和共享文件导入/导出继续保留。
- 权威配置仍是 `/data/vendor/zui_control/appopt/applist.conf`，但用户无需直接访问它。编辑器和导入都通过同一个 daemon 校验/事务接口写入，因此改规则不需要重刷镜像。`Download/ZuiControl/AppOpt.conf` 只是可导入/导出的共享副本，不是 daemon 热读源。
- 保存、删除、停止或整表替换成功后，daemon 自动停止正在运行的受影响 App；未运行则跳过。规则只有在目标下一次新进程启动时完整生效。
- 实机已打开编辑器、读取 canonical 零规则文本并点击应用；非取消式进度框出现，显示“正在应用 AppOpt 配置”和真实阶段，exact ACK 为 `done|replace_appopt_rules|rules=0;stoppedApps=0;stopFailed=0`，弹窗随后自动关闭。最终仍为 0 活动规则、service stopped、无 AppOpt PID。

进度反馈：

- P2、AppOpt 及相关长操作现在使用非取消式原生进度弹窗，不再靠固定 13 秒或界面乐观更新。弹窗只跟踪当前 requestId 的四字段 ACK，显示 daemon 的真实阶段；收到同 ID/同 command 的 `done` 或 `failed` 才关闭并刷新状态。
- P2 的 12–15 秒主要来自生成/校验、ZuiPP service 安全停止和新 PID 的 3 秒稳定窗，不是 App 卡死。AppOpt 通常约 5–7 秒；具体时间取决于受影响 App 数和 AppOpt 重启/停止。

#### 36/0.20.7 持久刷后真实结果

- 身份：系统为 ZUI 16.1.11.187；PackageManager 36/0.20.7，路径 `/system/priv-app/ZuiControlV36`，APK hash 与发布 hash一致，旧 V35 不存在。
- P1：system_server 仍是唯一刷新率 owner，daemon refresh disabled；未授权 shell Binder 被拒绝。对 Settings 做可逆 60Hz profile 时 target/actual 和 display active mode 都到 60，删除后回到 120，原 profile 未污染。没有改 P1，也没有进入 FPS cap。
- 开机 P2：active XML bind 后 ZuiPP 4614→6479，`state=done;reason=boot_active;stableSeconds=3`，证明重启由系统自动完成。P2 新增/删除的 membership、profile、hash、mount、新 PID和 target stop 均闭合；失败注入没有改变旧 membership/profile/hash/PID。
- 最终只剩鸣潮 profile。active/system game hash 均为 `cf787905a1a2d9a3afae69b7a48272ff0d86ff0e35c99d9a305e3dc31b634c1d`，performance hash 均为 `447277c22ba0d2cd378b05e2c99bc80d89d4fb57717deb78ac5ca760407e7a92`，两个路径保持 bind mount。鸣潮 `ThermalConfig=0 0 0`，三个 LimitConfig 段完全一致，四簇共享 level ID `900000` 且四个 Type 都存在。
- AppOpt：内置编辑器和 exact progress/ACK 通过；最终 `applist.conf` 0 活动规则、`init.svc.zui_appopt=stopped`、无 AppOpt PID、无 enabled flag。
- 相机：`STILL_IMAGE_CAMERA` 和模拟第三方 `IMAGE_CAPTURE` 都打开成功；SurfaceFlinger 始终 PID 1626/starttime 403，cameraserver 始终 PID 1919/starttime 429，无新增 tombstone、`No matching frame rate modes`、abort、fatal 或 CameraProvider DEAD_OBJECT。
- 项目精确路径未发现 AVC。仍有原厂 cameraserver 读取 `vendor_display_prop`、相机属性设置和厂商 HAL denial，以及相机 DSP unmap 错误；本轮功能成功且相关进程未重启，禁止把这些原厂日志误当 ZuiControl 缺权限而扩大策略。
- 云控继续为删除状态；官方 hosts 仍是 56 字节/`425c3e713d5bae19b031bc8639c20c6a23e311a54647ba1824cbf45969a11ff4`，旧脚本、runtime、setting 和 iptables/ip6tables 链不存在。

#### 新聊天当前最短下一步

1. 先只读确认设备仍为 36/0.20.7、V36、P1 owner 和本节最终 P2/AppOpt 基线；不要无原因重复全套写入测试。
2. 用户若报告 P2 不响应，记录 exact request ACK 的最后阶段、Game Assistant membership、target stop 结果、profile、active/system hash、ZuiPP PID/reload 和下一次真实 `onGameAppStart`。CPU/GPU XML 是 OEM 性能请求而非 hard cap，节点瞬时不同不能单独判失败。
3. 用户若报告 AppOpt 不响应，记录编辑器校验错误或 exact ACK、权威配置、AppOpt PID/service、目标 stop 结果，并在重新打开后读 `/proc/<pid>/status`。不要绕开 UI/daemon 直接写权威文件。
4. 只有出现可复现的新缺陷才制作下一包。仍不进入 FPS cap，不改 P1，不恢复 direct CPU/GPU sysfs、provider_direct、云控或旧 AsoulOpt。

### 0.7 2026-08-19 0.20.6 工作流优化、持久实测与交接（历史，已被 0.8 覆盖）

本节覆盖 0.6 及更早章节中的当前版本、hash、10 秒等待、手动强停、P2 两地添加和 AppOpt 无公开配置等表述。设备 `HA25HSZM` 已通过安全 7 项 9008 流程持久刷入 `versionCode=35` / `versionName=0.20.6`，不是临时 bind；成品、运行时状态和测试后的基线均已复核。

#### 当前成品与发布事实

- 当前生产 commit：`c1d8978a70fecd25163fae1ef6eb157d413a960e`
- GitHub Actions run：`32212847833`，结论 `success`：<https://github.com/xmy953538104/ZuiControl/actions/runs/32212847833>
- CI artifact：`D:\3.VScode\Mi\work\release_0206_32212847833`
- package：`com.zui.zuicontrol`；版本：35/0.20.6；system 路径：`/system/priv-app/ZuiControlV35/ZuiControl.apk`
- release 证书 SHA-256：`3fecf3a72ca0e0f24991d49e7306ef4a711711f48a66070755eb0237ecb3ed94`
- CI、payload、system 内嵌和 sidecar APK SHA-256：`a33e7fb38d9de3567bcd1544878c87ef0626ef8be8c4a4384e2a2d0bc72b85a7`
- 最终刷机目录：`D:\3.VScode\Mi\【B刷机】187`
- 安全自动刷机目录：`D:\3.VScode\Mi\flash\ZuiControl_9008_SAFE`
- 最终反抽 verifier 工作目录：`D:\3.VScode\Mi\work\verify_flash_zui_control_0206`；结论 `ok=true`

```text
5fc24c5b36ba7394125b87b681b62e38575172057c78417a0fa24746815be76b  boot.img
f2b49a1670b28fbe43b1a9bc91db5486668b3c1d4c0c8c0a2b7a5cc9f1dead47  super.img
9db326d3d605885c4afdac6b0883dc3f9c0bc2b9b1b3766cc4808945015967f5  vbmeta.img
b359b1010da64fd05306910133acee2ab4d5f81048d1d2ccd91caac48300d3b0  vbmeta_system.img
a33e7fb38d9de3567bcd1544878c87ef0626ef8be8c4a4384e2a2d0bc72b85a7  ZuiControl-v19-system.apk
a33e7fb38d9de3567bcd1544878c87ef0626ef8be8c4a4384e2a2d0bc72b85a7  ZuiControl-v19-release.apk
```

最终自动刷写日志为 `D:\3.VScode\Mi\flash\Log\ZuiControl_qdlrs_2026-08-19_11-51-18.log`。脚本从正常 Android 自动进入 9008，只写 super、boot_a/b、vbmeta_a/b、vbmeta_system_a/b，自动复位并确认同一 ADB serial、`boot_completed=1` 和 35/0.20.6。禁止把原始 99 项 XML 用于日常 ZuiControl 更新。

#### 0.20.6 当前用户语义

P2 性能调度：

- “游戏”不再靠 ZuiControl 猜。P2 添加器只列出已安装、可启动的 `/data/app` 用户 App；保存前查询 ZUI Game Assistant 自定义列表，不存在时单向自动加入，再提交 XML 事务。
- 单向同步是有意设计：ZuiControl 添加 P2 配置会加入 Game Assistant；在 Game Assistant 单独添加不会创建 ZuiControl profile；删除 P2 profile 也不会删除 Game Assistant 条目。这样只进游戏列表的 App 继续走 OEM 默认调度，只有在 ZuiControl 保存 profile 的 App 才走自定义 XML。
- 保存成功后 daemon 只在目标 App 当时确实有运行进程时自动 `force-stop`；未运行则返回 `target=not_running`，不做多余操作。用户无需去系统设置手动强停，保存完成后从桌面重新打开即可。
- ZuiPP 缓存进程必须重启，因为它不会可靠热读新 XML；不能删除“新 PID”校验。稳定观察由 10 秒缩短到 3 秒，用于确认新进程没有立即崩溃。鸣潮修改和恢复实测分别为 13.882 秒、14.209 秒，均得到 exact ACK、一次新 PID、`stableSeconds=3`、profile/XML/hash/mount 闭合。
- “息屏启动”只是旧自动化测试曾在屏幕关闭时用 adb 拉起 App 的异常测试场景，不是正常用户流程或产品入口。正常亮屏从桌面打开即可；只看到 Activity 焦点但没有 ZUI `onGameAppStart` 时不能误称游戏态已建立。

AppOpt：

- 只支持普通用户 App 的整包预设 `0-7`、`0-4`、`5-7`、`0-1`；不开放系统 App、线程名或自由 CPU 集合。
- 保存、删除、停止和批量导入成功后，daemon 自动关闭当时正在运行的受影响 App；没运行则跳过。用户只需在完成提示后重新打开目标 App。
- daemon 的权威配置仍是 `/data/vendor/zui_control/appopt/applist.conf`。公开可编辑副本是 `Download/ZuiControl/AppOpt.conf`；UI“导出共享配置”把权威配置同步到该文件，“导入共享配置”严格校验后一次性替换全部规则。公开文件不是 root daemon 实时读取源，避免半写文件、任意语法和共享存储权限问题。
- 规则保存实测 6.510 秒；批量清空实测 6.209 秒；从 UI 导入零规则文件实测 5.770 秒。`com.xmy.ap=0-1` 重开后 `/proc/<pid>/status` 为 `Cpus_allowed_list: 0-1`，清空后 service stopped、无 AppOpt PID、0 规则。
- 0.20.5 曾用 `text/plain` 写 MediaStore，系统会把文件改名为 `AppOpt.conf.txt`；0.20.6 改为 `application/octet-stream` 并已实机确认精确文件名 `AppOpt.conf`，没有 `.txt` 或重复副本。

#### 35/0.20.6 持久刷后真实结果

- 身份：PackageManager 为 35/0.20.6，路径 `/system/priv-app/ZuiControlV35`，系统 APK hash 与发布 hash 一致，旧 V34 不存在。
- P1：普通 shell Binder 被拒绝；Launcher 最终 `raw/current/last/applied` 一致，target/actual 均 120Hz，`refreshOwner=system`、`systemServiceAlive=true`、`daemonRefreshDisabled=true`、`displayVote=adaptiveRender`。没有改 P1，也没有进入 FPS cap。
- 开机 P2：ZuiPP PID 4636→6534，`state=done;reason=boot_active;stableSeconds=3`。鸣潮现有 profile 的首温区 GPU 720000→710000 后，运行中的目标被自动停止，ZuiPP 6534→11673，active/system 两对 hash 同步改变；恢复 720000 时目标未运行，ZuiPP 11673→13292，profile 逐字和两对 hash 均恢复。
- P2 最终 game hash：`cf787905a1a2d9a3afae69b7a48272ff0d86ff0e35c99d9a305e3dc31b634c1d`；performance hash：`447277c22ba0d2cd378b05e2c99bc80d89d4fb57717deb78ac5ca760407e7a92`。active 与 `/system/etc` 相同且保持 bind mount。Game Assistant 查询鸣潮返回 true。
- AppOpt：`com.xmy.ap=0-1` 后运行中的目标自动停止，重开后主进程 CPU mask 为 0-1；批量清空后目标再次自动停止。最终共享文件只含注释，权威配置 0 活动规则，service stopped、无 AppOpt PID。
- UI：性能页明确显示自动加入游戏助手/自动关闭语义；系统页的添加、停止、导入和导出入口均可见。真实点击导出生成精确 `Download/ZuiControl/AppOpt.conf`；真实点击“导入并应用”收到 exact done ACK，耗时 5.77 秒。
- 相机：系统 `STILL_IMAGE_CAMERA` 与模拟第三方 `IMAGE_CAPTURE` 都打开成功；SurfaceFlinger 始终 PID 1644/starttime 396，cameraserver 始终 PID 1870/starttime 417，没有新增 tombstone、`No matching frame rate modes`、CameraProvider DEAD_OBJECT 或 fatal。
- 项目相关 AVC 未发现。原厂 `system_server dac_read_search` 和 `cameraserver` 读取 `vendor_display_prop` denial 仍存在；它们在旧稳定包也存在且本次未造成进程重启，禁止为消日志扩大项目权限。

#### 新聊天当前最短下一步

1. 先只读确认设备仍为 35/0.20.6、V35、上述 APK/super hash、P1 owner 和 P2/AppOpt 最终基线；不要无原因重复全套写入测试。
2. 用户若报告 P2 不响应，记录 exact ACK、Game Assistant membership、目标运行状态、profile、active/system hash、ZuiPP 旧/新 PID 与真实 `onGameAppStart`；CPU/GPU 节点不是 hard cap，不能单独判失败。
3. 用户若报告 AppOpt 不响应，记录 exact ACK、权威配置、AppOpt PID/service、目标是否被自动停止，并在重新打开后读取 `/proc/<pid>/status`；共享文件必须通过 UI 导入，不是保存即热生效。
4. 只有出现可复现的新缺陷才制作下一包。仍不进入 FPS cap，不改 P1，不恢复 direct CPU/GPU sysfs、provider_direct、云控或旧 AsoulOpt。

### 0.6 2026-08-18 0.20.3 刷后根因、0.20.4 成品与 9008 自动化（历史，已被 0.7 覆盖）

本节覆盖 0.5 的版本、hash、“0.20.3 待刷”和下一步。设备已经通过新的最小化 9008 自动流程持久刷入 33/0.20.4，并完成开机、P2 修改/恢复、真实游戏重入、P1、相机、AppOpt、云控删除和 AVC 全功能回归。0.20.3 的 graceful stop 判断问题已经在 0.20.4 中修复；当前不再存在“临时 daemon bind”或“待刷验证”状态。

#### 0.20.3 刷后发现的真实问题

0.20.3 开机后 `zui_control_zuipp_reload_state` 为：

```text
state=error;stage=stop_services;oldPid=4750
```

daemon 日志同时出现：

```text
cmd: Failure calling service activity: Failed transaction (2147483646)
cannot stop ZuiPP service before reload: com.zui.pp/...OverHeatStatsService
```

根因有两部分：

1. 本机 ZUI 的 `am stop-service` 即使打印 `Service stopped`，退出码仍为 255；目标未运行时打印 `Service not stopped: was not running.`，退出码同样为 255。0.20.3 用 shell 退出码判断成功，因此把真实成功误判为失败。
2. 0.20.3 把 daemon 的 `/data/vendor/zui_control/log/controld.log` 文件描述符直接继承给 `am/cmd`。该描述符经 Binder 进入 system_server 后触发 system_server 对 shell-owned 日志的 append AVC，进而出现 `Failed transaction`。这不是缺少一条应该放宽的 SELinux 权限，而是不该跨 Binder 传入该 FD。

0.20.4 不改四个精确 service 的顺序，也不扩大 SELinux。它先在命令替换中捕获 `am stop-service` 输出，再由 daemon 自己写日志；只接受上述两种明确成功文本。瞬时 Binder 失败最多重试 5 次；5 次都没有明确成功文本才发布 `stage=stop_services` 并禁止 SIGTERM。

#### 0.20.4 已完成的修复前临时验证（历史证据）

- 开机 active reload：ZuiPP 从 `11699:115086` 切换为 `23574:153977`，四个 service 均得到明确 stop/no-op 文本，终态 `state=done;reason=boot_active;stableSeconds=10`，没有 fatal/NPE。
- P2 修改：把鸣潮首温区 GPU 请求从 720000 改为 710000，exact ACK done，profile、active/system XML、bind mount 和 hash 全部闭合，ZuiPP 只从 23574 切到 25079 一次并稳定 10 秒。
- P2 恢复：恢复 720000 后 exact ACK done，ZuiPP 只切到 26547 一次；原始 game/performance hash 分别恢复为 `cf787905a1a2d9a3afae69b7a48272ff0d86ff0e35c99d9a305e3dc31b634c1d` / `447277c22ba0d2cd378b05e2c99bc80d89d4fb57717deb78ac5ca760407e7a92`。
- 鸣潮重入：看到同一 package 的 `onGameAppStart`、GameHelper `initGameHelper`、ZuiPP `notifyPerfStatus` 和 `writeSavageMode::open::1,status::0`，证明不是只停在 provider 返回值。
- P1 回归：system_server owner、daemon refresh disabled、未授权 Binder 拒绝、60Hz 可逆 profile 测试和恢复默认 120 全部通过；最终 profile 只有 default 120。
- 相机回归：系统相机、`IMAGE_CAPTURE`、`VIDEO_CAPTURE` 均通过；boot ID、SurfaceFlinger/cameraserver PID+starttime 和 tombstone 列表不变，无 `No matching frame rate modes`、DEAD_OBJECT 或 fatal。
- AppOpt 回归：测试 App 设为 `0-1` 后 34 个存活线程全部命中，删除规则 exact ACK done；最终 0 规则、service stopped、无 PID、无 enabled flag。
- 云控继续为 null/不存在。修复后没有新增项目 AVC；旧 0.20.3 的 system_server append denial 是本次根因证据。原厂 cameraserver/vendor_display_prop 等 denial 仍不是项目问题，禁止扩大权限。

以上 live 验证当时使用 `/data/local/tmp` 到 `/system/bin/zui_controld` 的临时 bind，用于在重封前证明修复逻辑成立。后续已经通过 9008 把同一生产内容持久写入系统分区，并在全新开机后重复验证；不要再把当前设备描述为临时 bind。

#### 33/0.20.4 发布事实

- 修复生产 commit：`523990b4062f06d8bf5ee27713ac55e5348458ad`
- 9008 自动化 commit：`362ae7f65dcd3a12b95cebaefc08ef88b4d4f138`
- GitHub Actions App build run：`32147587045`，结论 `success`：<https://github.com/xmy953538104/ZuiControl/actions/runs/32147587045>
- GitHub Actions qdl-rs Windows build run：`32149002631`，结论 `success`：<https://github.com/xmy953538104/ZuiControl/actions/runs/32149002631>
- 下载并用于 payload 的 CI artifact：`D:\3.VScode\Mi\work\ci_32147587045`
- package：`com.zui.zuicontrol`；版本：33/0.20.4；system 路径：`/system/priv-app/ZuiControlV33/ZuiControl.apk`
- release 证书 SHA-256：`3fecf3a72ca0e0f24991d49e7306ef4a711711f48a66070755eb0237ecb3ed94`
- CI APK、payload APK、最终 system 内嵌 APK和两个 sidecar APK SHA-256：`3534bf88224cf7c61b317e35720dc7ae4ca9ec18de70091a66ad94adc24cb18f`
- 最终刷机目录：`D:\3.VScode\Mi\【B刷机】187`

```text
5fc24c5b36ba7394125b87b681b62e38575172057c78417a0fa24746815be76b  boot.img
8b31b4e742794e3e8c3c5d05dd2fe7307f53c7aeaa76a10833c810c48fd3c80c  super.img
9db326d3d605885c4afdac6b0883dc3f9c0bc2b9b1b3766cc4808945015967f5  vbmeta.img
2baf3432bda31c74cc421932b8c7292f38e4750e36bc09a6bdfb838b457a27f5  vbmeta_system.img
3534bf88224cf7c61b317e35720dc7ae4ca9ec18de70091a66ad94adc24cb18f  ZuiControl-v19-system.apk
3534bf88224cf7c61b317e35720dc7ae4ca9ec18de70091a66ad94adc24cb18f  ZuiControl-v19-release.apk
```

发布顺序为同一 CI run 的 release APK/payload → Apply payload → 重建 `system_a.img` → `SignNoFecDryRun` → `SignNoFec` → 签名后重新 `PackSuper`。最终 `VerifyZuiControlFlashPackage.ps1` 从刷机目录的成品 super 反抽全部动态分区和 system EROFS、解码成品 `services.jar`，返回 `ok=true`；33/0.20.4、V33、release 证书、daemon 输出判断/重试、P1/P2/AppOpt/SELinux 边界和 sidecar hash 全部通过。

#### 9008 自动化已完成并通过首次真实刷写

- 现有 GeekFlashTool 全量目录包含 99 个 program 项，会写 GPT、persist、FRP、modemst 等与 ZuiControl 更新无关的高风险区域，自动化禁止直接使用这些 XML。
- `scripts/PrepareZuiControl9008Package.ps1` 校验最终 SHA256、镜像长度和原始 XML 的 sector/LUN 字段，然后在 `D:\3.VScode\Mi\flash\ZuiControl_9008_SAFE` 生成独立包。该包只有一个 `rawprogram_zuicontrol.xml`、没有 patch XML，只写 7 项：LUN0 super、vbmeta_system_a/b；LUN4 boot_a/b、vbmeta_a/b。
- `scripts/FlashZuiControl9008.ps1` 默认只做 Preflight。`-Mode Flash` 会先校验唯一 ADB 设备 `HA25HSZM`、TB321FU、187 和 root，再 `reboot edl`，只接受一个 `05C6:9008` COM 口，调用 Qualcomm 官方开源 `qdl-rs` 串口后端执行上述 7 项，要求成功标记后自动 reset system，并等待 Android boot completed 和 33/0.20.4。
- qdl-rs 固定使用 Qualcomm `qdlrs` commit `412f90bc08cc3a687d552ff599da29043c4f54f4`。Windows 构建 workflow 是 `.github/workflows/build-qdlrs-windows.yml`；详细步骤和恢复边界见 `docs/ZuiControl_9008_AUTOMATION_GUIDE_2026-08-18.md`。

2026-08-18 首次真实自动刷写已成功：脚本从正常 Android 自动执行 `reboot edl`，识别唯一 `COM3`，完成 Sahara/Firehose/UFS 配置，以约 42–43 MB/s 写完 13 GB super 和其余 6 个双槽 boot/vbmeta 项，qdl-rs 返回 `All went well! Resetting to system`。设备自动回到 Android，脚本确认同一 ADB serial `HA25HSZM`、`boot_completed=1` 和 PackageManager 33/0.20.4。完整日志：

```text
D:\3.VScode\Mi\flash\Log\ZuiControl_qdlrs_2026-08-18_22-36-35.log
```

qdl-rs Windows 二进制 SHA-256：

```text
54330234768a651540eabc108d72cad506c6f3511ebb94e04fec90ca7844332a
```

#### 0.20.4 持久刷后验证（当前设备真实状态）

- 设备/系统：`HA25HSZM`，TB321FU，`TB321FU_CN_OPEN_USER_Q00040.0_U_ZUI_16.1.11.187_ST_250227`；App 来自 `/system/priv-app/ZuiControlV33/ZuiControl.apk`，PackageManager 为 33/0.20.4。
- 开机 P2：active XML 在 ZuiPP 启动后 bind，reload 从 PID 4646 切到 6972，`state=done;reason=boot_active;stableSeconds=10`；没有 0.20.3 的 `Failed transaction` 或 `stage=stop_services`。
- P1：普通 shell Binder 调用被拒绝；system UID 对 Settings 做 60Hz 可逆规则时 target/actual 都为 60，删除规则后都回到 120；最终 `refreshOwner=system`、`daemonRefreshDisabled=true`，原 profile 未被污染。
- P2 事务：鸣潮首温区 GPU 720000→710000 得到 exact done ACK，ZuiPP 6972→12039 并稳定 10 秒；恢复 720000 再得到 exact done ACK，ZuiPP 12039→12819，profile 逐字恢复，active/system 两对 hash 回到本节发布 hash。
- 鸣潮重入：第一次熄屏启动被 ZuiMode 正确判为非游戏态，因此不计成功；唤醒后从桌面重入，看到同一 package 的 `onGameAppStart`、GameHelper `initGameHelper`、TAssistant、ZuiPP `notifyPerfStatus`、`writeSavageMode::open::1,status::0`，并输出恢复后 CPU/GPU 三温区。这个对照证明“App 在前台”不等于“ZUI 游戏态已进入”。
- 相机：系统相机、`IMAGE_CAPTURE`、`VIDEO_CAPTURE` 全部打开；boot ID 不变，SurfaceFlinger PID 1639、cameraserver PID 1938 不变，没有新 tombstone 或匹配 fatal/DEAD_OBJECT。
- AppOpt：鸣潮 `0-1` 预设 exact done，服务运行且主进程 209 个线程全部为 `Cpus_allowed_list: 0-1`；删除 exact done 后强停目标 App，最终 0 规则、service stopped、无 AppOpt PID。
- 云控：hosts 仍为官方 56 字节/`425c3e713d5bae19b031bc8639c20c6a23e311a54647ba1824cbf45969a11ff4`，旧 Settings/iptables/文件链不存在。
- 最终 XML：active/system game hash 均为 `cf787905a1a2d9a3afae69b7a48272ff0d86ff0e35c99d9a305e3dc31b634c1d`，performance hash 均为 `447277c22ba0d2cd378b05e2c99bc80d89d4fb57717deb78ac5ca760407e7a92`。
- 没有新增项目 AVC。仍有原厂 system_server DAC、cameraserver 读取 vendor_display_prop 等 denial；功能成功时同样出现，禁止为其扩大 ZuiControl 权限。唯一匹配 NPE 来自联想应用商店 `ImeiHelper/MiitSDKTool`，不是 ZuiControl/ZuiPP/相机。

#### 新聊天当前最短下一步

1. 先只读确认当前仍是 `HA25HSZM`、33/0.20.4、V33 路径和四个最终 hash；这些已在 2026-08-18 持久刷后全部通过，不要再次制造无意义的全套写入测试。
2. 用户若报告具体体验问题，先复现并同时记录屏幕唤醒/ZuiMode 游戏态、exact ACK、XML hash、ZuiPP PID/reload 和真实原厂重入链；不能只看频率节点或 App 焦点就下结论。
3. 下一版本只有在出现可复现的新缺陷时再制作。9008 日常更新只允许使用 `FlashZuiControl9008.ps1` 生成的 7 项安全包，禁止调用原始 99 项全量 XML。
4. 仍不进入 FPS cap、不改 P1、不恢复 direct CPU/GPU sysfs、provider_direct、云控或旧 AsoulOpt。

### 0.5 2026-08-18 0.20.2 实机全功能闭环与 0.20.3 P2 reload 修复包（历史，已被 0.6 覆盖）

本节覆盖 0.4 的“待刷”状态、版本、hash 和下一步。设备已经刷入并完整验证 31/0.20.2；本轮唯一新增的真实缺陷是 ZuiPP XML reload 会让原厂 `OverHeatCleanService` 以空 Intent 重启并崩溃一次。该问题已用实机对照实验定位并修复为 32/0.20.3。0.20.3 已完成 CI、签名、重封和最终 super 反向校验，但尚未刷入，所以不能提前宣称新 reload 路径已持久实机通过。

#### 31/0.20.2 的真实刷后结果

- 身份与安全状态通过：PackageManager 和 `/system/priv-app/ZuiControlV31/ZuiControl.apk` 均为 31/0.20.2；ADB、`su` 可用，SELinux Enforcing；旧 V30、旧 `ZuiControl` 目录和 cache helper 不存在。
- P1 完整通过：未授权 Binder 调用被拒绝；system_server 是唯一刷新率 owner，daemon refresh disabled，场景 `raw/current/last/applied` 与 profile 记忆正确；60/90/120 的目标和物理 mode 一致。144/165 在持续触控/渲染时能达到目标，空闲时会被 adaptive display 降回较低 mode，这是“目标/上限”语义，不是规则失效。测试后已恢复默认 120，未生成 SystemUI profile。
- 相机完整通过：系统相机、外部 `IMAGE_CAPTURE` 和 `VIDEO_CAPTURE` 均没有设备重启；SurfaceFlinger/cameraserver PID 与 starttime 不变，无新增 tombstone、`No matching frame rate modes`、CameraProvider `DEAD_OBJECT` 或 fatal。
- P2 事务与运行链通过：对鸣潮把 GPU 首温区请求 720000 改为 710000，exact ACK、profile、active XML、bind hash、共享 CPU level ID、ZuiPP 新 PID 稳定 10 秒均闭合；重新进入鸣潮后看到真实 system game-start 和 ZuiPP 游戏识别；随后已恢复原 profile 和原 XML hash。畸形请求失败且旧配置保持不变。CPU/GPU 是 OEM 请求，不是 hard cap；热控仍可把运行值压低。
- AppOpt 完整通过：测试用户 App 的 `0-1`、`0-4`、`5-7`、`0-7` 四个预设均在强停重开后使全部存活线程落入对应 CPU 集合；系统 App 和非法 preset 被拒绝；修改、删除、重复删除、全局停止和再次启动均正确。最终已恢复 0 规则、service stopped、无 PID、无 enabled flag。
- 云控删除继续通过：官方 hosts 为 56 字节两行 localhost，旧脚本、runtime、setting 和 iptables/ip6tables 链均不存在。
- 项目相关 AVC 为零。相机日志仍有原厂 `cameraserver` 查询 `vendor_display_prop` 的 denial，但不属于 ZuiControl、没有造成相机故障，禁止为此扩大项目 SELinux 权限。

#### 实机发现的 ZuiPP reload 缺陷和最小修复

0.20.2 每次 P2 保存会直接向 `com.zui.pp` 发送 SIGTERM。原厂 persistent 进程重启时，`OverHeatCleanService` 收到空 Intent 并在 `OverHeatCleanService.java:139` 触发一次 NPE；系统随后再次拉起进程并稳定，因此最终 P2 看似成功，但中间存在一次真实应用崩溃和额外重启。

实机对照结果：只停 `OverHeatCleanService` 仍会复现；在 SIGTERM 前依次停止下列四个原厂 service，则 ZuiPP 只发生一次干净 PID 切换，无 fatal，并重新读取 PerformanceConfig：

1. `com.zui.pp/com.zui.power.overheat.OverHeatStatsService`
2. `com.zui.pp/com.zui.power.overheat.OverHeatCleanService`
3. `com.zui.pp/com.zui.power.overheat.StubbornStatsService`
4. `com.zui.pp/.service.MainService`

0.20.3 因而只在既有 reload 前加入这四个精确 `am stopservice`。任一步停止失败都会发布 `state=error;stage=stop_services` 并禁止发送 SIGTERM；没有恢复 provider_direct、direct CPU/GPU sysfs、daemon 刷新率或 FPS cap，也没有修改 P1。

#### 32/0.20.3 发布事实

- 生产代码 commit：`8c4ae5327af59006a738a13d41103c80f82d40c3`
- GitHub Actions run：`32141595553`，结论 `success`：<https://github.com/xmy953538104/ZuiControl/actions/runs/32141595553>
- 下载并用于 payload 的 CI artifact：`D:\3.VScode\Mi\work\release_0.20.3_32141595553`
- package：`com.zui.zuicontrol`；版本：32/0.20.3；system 路径：`/system/priv-app/ZuiControlV32/ZuiControl.apk`
- release 证书 SHA-256：`3fecf3a72ca0e0f24991d49e7306ef4a711711f48a66070755eb0237ecb3ed94`
- CI APK、payload APK、最终 system 内嵌 APK 和两个旁载 APK SHA-256：`9c5c7f104607cda4f38c4a1930a139d33a22d60966c1154d0b40e0f74370a985`
- 最终刷机目录：`D:\3.VScode\Mi\【B刷机】187`

```text
5fc24c5b36ba7394125b87b681b62e38575172057c78417a0fa24746815be76b  boot.img
58342f892641faa1e1a80535a5ab67b131bdcc60876505f32c255222b30ffcc2  super.img
9db326d3d605885c4afdac6b0883dc3f9c0bc2b9b1b3766cc4808945015967f5  vbmeta.img
4f228e1987403b9aaec46eadf2bce28b8fb1eea4a49945646423affae1938550  vbmeta_system.img
9c5c7f104607cda4f38c4a1930a139d33a22d60966c1154d0b40e0f74370a985  ZuiControl-v19-system.apk
9c5c7f104607cda4f38c4a1930a139d33a22d60966c1154d0b40e0f74370a985  ZuiControl-v19-release.apk
```

发布顺序为：下载同一 CI run 的 release APK/payload → Apply payload → 重建 `system_a.img` → `SignNoFecDryRun` → `SignNoFec` → 签名后重新 `PackSuper`。最终 `VerifyZuiControlFlashPackage.ps1` 从刷机目录的成品 super 反抽动态分区/system EROFS、解码成品 `services.jar`，返回 `ok=true`；V32、签名、四个 graceful stop 组件和失败门禁、P1/P2/AppOpt/SELinux 边界、AVB 镜像均通过。

#### 刷入 0.20.3 后只需完成的最终确认

1. 确认 PackageManager 和 `/system/priv-app/ZuiControlV32/ZuiControl.apk` 为 32/0.20.3，旧 V31/V30/旧 `ZuiControl` 目录不存在。
2. 做一次可恢复的 P2 保存：要求 exact ACK done、四个 service stop 成功、ZuiPP 只有一次新 PID 切换并稳定 10 秒；全 buffer logcat 中不得再出现 `OverHeatCleanService` fatal/NPE。随后强停并重进游戏，确认原厂 game-start/ZuiPP 识别，再恢复原 profile。
3. 快速回归 P1 目标/actual、相机一次和 AppOpt 一个预设，并检查项目相关 AVC。0.20.3 没改这些链路，0.20.2 的完整结果仍是有效基线。

当前明确边界：FPS cap 未交付；144/165 是 adaptive display 目标/上限，空闲会降频；P2 是原厂 XML/OEM 请求而不是硬 cap，只对 ZUI 识别的游戏承诺重入链；AppOpt 只支持普通用户 App 的整包 CPU 预设，修改后必须强停重开目标 App；云控已删除且无用户操作入口。

### 0.4 2026-08-18 0.20.1 实机闭环与 0.20.2 AppOpt 修复包（历史，已被 0.5 覆盖）

本节覆盖 0.3 的“待刷”状态、版本、hash 和下一步。当前设备已刷并完整验证 30/0.20.1；由实测发现的 AppOpt 包校验问题已经修复为 31/0.20.2，并完成 CI 签名、镜像重建和最终 super 反向抽查。0.20.2 尚未刷入，不能把临时 bind 验证写成新镜像的持久实机验证。

#### 30/0.20.1 的真实刷后结果

- 身份闭合：PackageManager 与 `/system/priv-app/ZuiControlV30/ZuiControl.apk` 均为 30/0.20.1，APK SHA-256 为 `7e60f25103ec29521652c6b3e827dc05e7a6150d9836aa1c5d808fd37bebeac8`；旧 `/system/priv-app/ZuiControl` 和旧 cache helper 均不存在。ADB、`su` 可用，SELinux 为 Enforcing。
- P1 通过：`raw/current/last/applied`、默认 120、system owner、daemon refresh disabled、adaptive render 均正确；未授权 shell Binder 调用被拒绝。用 system UID 可逆测试 60Hz 时 target、actual 和 active mode 一致，删除测试规则后已恢复默认 120；没有生成 SystemUI profile。
- 相机通过：分别启动系统相机、外部 `IMAGE_CAPTURE` 和 `VIDEO_CAPTURE`，boot ID、SurfaceFlinger/cameraserver PID 与 starttime 均未变化，没有新增 tombstone、`No matching frame rate modes`、`DEAD_OBJECT` 或 fatal。旧“点相机像重启”的 SurfaceFlinger 崩溃链未复现。
- P2 事务和运行链通过：鸣潮原 profile、active XML 与 `/system/etc` bind hash 先保存；把首温区 GPU 请求从 720000 改到 710000 后，exact ACK done、profile 和两份 XML hash 同步变化、LimitConfig ID 变化、ZuiPP PID 更新并稳定 10 秒。强停并重进鸣潮后看到真实 `onGameAppStart`、GameHelper/provider 连接及 ZuiPP 游戏态；随后恢复原 profile 和原 hash。畸形请求返回 failed，profile/XML hash 不变。再次重启设备时，即使 hash 未变，boot bind 后仍将 ZuiPP 从旧 PID 4730 重载到新 PID 6978，并得到 `state=done;reason=boot_active;stableSeconds=10`。
- P2 的 CPU max 节点能反映请求；测试时 GPU 因约 70°C、`thermal_pwrlevel=7` 被原厂热控压到 500MHz，因此节点不严格等于输入不能单独判失败。这里交付的是 XML/OEM 性能请求，不是 direct sysfs 硬 cap，也不恢复自建 provider bridge。
- 云控删除继续通过：hosts 为官方 56 字节两行 localhost，旧脚本、runtime、setting 和 iptables/ip6tables 链均不存在。

#### AppOpt 实机发现、根因与修复

0.20.1 首次给用户 App `com.xmy.ap` 保存 `0-1` 时，ACK 正确从 processing 进入 failed，配置回滚也正确，但规则无法生效。根因不是亲和度二进制，而是 daemon 在读取 `applist.conf` 的 `while ... done < file` 循环中调用 `pm path`：PackageManager 子进程继承了受保护配置文件作为标准输入，触发 system_server 对 `/data/vendor/zui_control/appopt/applist.conf` 的 SELinux 读取拒绝，最终把正常用户 App 误判为不允许。

最小修复为 `pm path "$1" </dev/null`，切断无关文件描述符继承；没有扩大 SELinux 权限，也没有放宽 set 的“已安装 `/data/app` 用户 App”门槛。同时把空的 `init.svc.zui_appopt` 健康值规范为 stopped，并让 0 活动规则升级时恢复当前安全的仅注释模板。

在 0.20.1 设备上用重启即失效的临时 bind 替换修复版 daemon/prepare 后，已真实验证：

- `0-1`：采样 34 个线程，全部落在 CPU 0-1；
- `0-4`：稳定重采样 28 个线程，全部落在 CPU 0-4；
- `5-7`：采样 36 个线程，全部落在 CPU 5-7；
- `0-7`：采样 39 个线程，全部落在 CPU 0-7；
- AppOpt 运行域为 `u:r:performanced:s0`，没有新增 AppOpt AVC；系统 App set 被拒绝且原规则不变；删除最后规则及重复删除均 done；最终已恢复 0 规则、service stopped、无 PID、无 enabled flag。

第一次 `0-4` 采样中有一个线程恰好退出，导致单次线程数变化；目标进程稳定后重采样全部符合。这是 `/proc` 线程生命周期采样竞争，不是规则越界。

#### 31/0.20.2 发布事实

- 生产代码 commit：`259ab36314d580be63f3382f388c6f99e85cf297`
- GitHub Actions run：`32134948150`，结论 `success`：<https://github.com/xmy953538104/ZuiControl/actions/runs/32134948150>
- 下载并用于 payload 的 CI artifact：`D:\3.VScode\Mi\work\release_0.20.2_32134948150`
- package：`com.zui.zuicontrol`；版本：31/0.20.2；system 路径：`/system/priv-app/ZuiControlV31/ZuiControl.apk`
- release 证书 SHA-256：`3fecf3a72ca0e0f24991d49e7306ef4a711711f48a66070755eb0237ecb3ed94`
- CI APK、payload APK、最终 system 内嵌 APK和两个旁载 APK SHA-256：`b59b4d0bba284bbb4416ef2f854ddf9e9680601c1c09ce6b10e87b1e456fa374`
- 最终刷机目录：`D:\3.VScode\Mi\【B刷机】187`

```text
5fc24c5b36ba7394125b87b681b62e38575172057c78417a0fa24746815be76b  boot.img
78de34e36e3244c2c188e8547de164165f6c956e222efc0a4be7a209ecd78ce1  super.img
9db326d3d605885c4afdac6b0883dc3f9c0bc2b9b1b3766cc4808945015967f5  vbmeta.img
88811d64351dd449b8addad4775b045e44e48352fa8893a7e9ac910c7d784002  vbmeta_system.img
b59b4d0bba284bbb4416ef2f854ddf9e9680601c1c09ce6b10e87b1e456fa374  ZuiControl-v19-system.apk
b59b4d0bba284bbb4416ef2f854ddf9e9680601c1c09ce6b10e87b1e456fa374  ZuiControl-v19-release.apk
```

实际发布顺序为：下载同一 run 的 release APK/payload → Apply payload → 重建 `system_a.img` → `SignNoFecDryRun` → `SignNoFec` → 签名后重新 `PackSuper`。最终 `VerifyZuiControlFlashPackage.ps1` 从刷机目录的成品 super 反抽动态分区和 system EROFS、解码成品 `services.jar`，返回 `ok=true`；V31 版本/签名、daemon 修复、AppOpt 默认配置和权限边界、P1/P2 生产标记、AVB 镜像均通过，旧 V30/旧 app 目录和 cache helper 被拒绝。

#### 刷入 0.20.2 后只需完成的持久确认

1. 确认 PackageManager 和 `/system/priv-app/ZuiControlV31/ZuiControl.apk` 为 31/0.20.2，旧 V30 与旧 `ZuiControl` 目录不存在。
2. 在 AppOpt 中对普通用户 App 依次保存 `0-1`、`0-4`、`5-7`、`0-7`；每次等 exact ACK done，强停并重开目标 App，再抽查全部存活线程的 affinity。系统 App必须继续被拒绝。最后删除规则，确认 stopped、无 PID、0 规则和无新增 AVC。
3. P1/相机和 P2 已在相同 0.20.1 基线完整通过；0.20.2 未改这些架构，只做回归抽查即可。仍应查看 dmesg 和全 buffer logcat AVC，以确认修复持久落盘后的设备策略表现。

Windows 侧仍没有单独完成完整 `secilc` 编译；最终镜像策略已被 verifier 反抽检查，0.20.1 live SELinux 也通过，但 0.20.2 的最终结论仍以刷后 AVC 为准。

### 0.3 2026-08-18 实机闭环与 0.20.1 待刷包（历史，已被 0.4 覆盖）

本节覆盖 0.2 的包版本、hash、发布事实和“下一步”，也覆盖后文旧 provider_direct、云控、AppOpt 只读状态与固定延时请求流程。P1 没有进入 FPS cap，也没有恢复 direct CPU/GPU sysfs 或旧 AsoulOpt。

#### 已在 0.20.0 设备上得到的真实结果

TB321FU 已连接，ADB、`su` 可用且 SELinux 为 Enforcing。对当时已刷的 0.20.0 做完了只读与可逆实测：

- P1/Binder/QS/刷新率链路通过。`zui_control` 存在，system_server 是唯一刷新率 owner，daemon 显示 refresh disabled；未授权 shell Binder 调用被拒绝，真实场景/current/last、profile 记忆、QS 不学习 SystemUI、目标与实际 mode 均闭合。
- 相机连续执行 8 轮系统相机和外部 capture 入口，没有设备重启，没有 SurfaceFlinger/cameraserver PID 起始时间变化，没有新增 tombstone，也没有再出现 `No matching frame rate modes`。因此 61a4b26 的 adaptive render vote 根因修复已被实机确认；本轮不再改 P1。
- 云控删除实机通过：hosts 是官方 56 字节两行 localhost 文件；没有旧脚本、runtime 目录、setting、iptables/ip6tables chain 或 jump。云控不再是产品功能，不恢复旧链。
- P2 active XML 与 `/system/etc` bind 内容 hash 一致，鸣潮三槽、`ThermalConfig=0 0 0`、共享 CPU level ID 和四簇频率字典均通过结构检查。保存后“数值不响应”不是一个单点：旧 App 会在固定 13 秒后解锁且共享单槽可被覆盖；XML promote 成功也可能吞掉 ZuiPP reload 失败；而 ZuiPP 重启后，TAssistant/原厂 game state 必须等下一次真实 `onGameAppStart` 才重新连接。所以必须等待真实终态，再彻底退出并重进游戏。
- AppOpt 用临时 live SELinux 规则对用户 App `com.xmy.ap` 验证了四个整包预设：`0-7`、`0-4`、`5-7`、`0-1` 均使目标进程全部线程落到对应 CPU 集合，没有新增相关 AVC。测试后已恢复 0 条规则、service stopped、无 PID。线程名规则和自由文本没有验证，不交付。
- 设备 system APK 已是 0.20.0，但 PackageManager 仍报告 28/0.19.9，根因是同一 `/system/priv-app/ZuiControl` codePath 的旧扫描状态，并非 APK 内容错误。0.20.1 改用新目录 `ZuiControlV30`，同时删除旧目录；禁止通过删除 PackageManager cache 解决。

#### 0.20.1 的最小修复

当前 App 为 `versionCode=30` / `versionName=0.20.1`：

- App 删除 `onCreate` 自动写 `status`，不再用 720ms/13s 定时器或乐观修改列表。每个请求使用唯一 ID，并只接受同 ID、同 command 的四字段终态 ACK：`id|done|cmd|detail` 或 `id|failed|cmd|reason`；等待上限 120 秒，pending 请求不能被新请求覆盖。
- daemon 将请求和终态 ACK 作为两行原子 receipt 持久化，重启可安全 replay；旧单行 receipt 只迁移为失败，不会把历史命令再执行一次。
- P2 profile、active XML、bind/reload 成为一笔可恢复事务。生成、promote、mount 或 ZuiPP 稳定重载任一步失败，都会恢复旧 profile、旧 active 和旧 runtime；reload 失败不再被 `|| true` 吞掉。
- daemon 每次启动都先使旧 `last_reloaded_hash` 失效。即使 XML hash 与上次开机相同，boot bind 后若 ZuiPP 正在运行，仍会真实重启并确认新 PID 稳定 10 秒；若 ZuiPP 尚未运行，允许终态 `skipped;reason=zuipp_not_running`，其首次启动会读取已经 bind 的 active XML。这样不会让旧跨开机 receipt 跳过一次本应执行的 reload。
- 不恢复自建 GameModeProvider bridge。保存成功后由原厂 GameHelper 在真实游戏重入时调用 provider；provider 返回 rows=1 只表示模式值被接纳，不能冒充 XML 已应用。
- AppOpt 增加最小 UI：只可选择已安装用户 App，只提供 `0-7`、`0-4`、`5-7`、`0-1` 四个整包预设，可修改、删除或全局停止。set 严格要求 `/data/app`；删除允许清理已卸载的 stale 规则，并具备崩溃重放幂等性。默认配置 0 条活动规则，service stopped。
- AppOpt SELinux 只加入实机证明需要的 `dac_override kill`、配置文件 `watch/watch_reads`、目标进程 `getsched/signull` 和目录探测 dontaudit；成品 verifier 拒绝更宽的 signal/sigkill 或额外 performanced 调度授权。
- App 安装路径改为 `/system/priv-app/ZuiControlV30/ZuiControl.apk`；成品中必须不存在旧 `ZuiControl` 目录、`clear_package_cache.sh` 及 rc cache mutation。

#### 0.20.1 发布事实

- 生产代码 commit：`767a4f964d7e3530bd1e05cdd97ca94a5a234f17`
- GitHub Actions run：`32119890097`，结论 `success`：<https://github.com/xmy953538104/ZuiControl/actions/runs/32119890097>
- CI artifact：`D:\3.VScode\Mi\work\ci_artifacts\zuicontrol_32119890097`
- package：`com.zui.zuicontrol`；版本：30/0.20.1
- release 证书 SHA-256：`3fecf3a72ca0e0f24991d49e7306ef4a711711f48a66070755eb0237ecb3ed94`
- CI APK 与 payload/最终 system APK SHA-256：`7e60f25103ec29521652c6b3e827dc05e7a6150d9836aa1c5d808fd37bebeac8`
- 最终刷机目录：`D:\3.VScode\Mi\【B刷机】187`

```text
5fc24c5b36ba7394125b87b681b62e38575172057c78417a0fa24746815be76b  boot.img
e755cb3544314cef8ecc764dc2325cd2b0fa45d523d499c721afe2a096d99b2d  super.img
9db326d3d605885c4afdac6b0883dc3f9c0bc2b9b1b3766cc4808945015967f5  vbmeta.img
e47c5a7973e3d89e2d96e2827869c3953f3582ffad907cfb967c18d9d5ccc064  vbmeta_system.img
7e60f25103ec29521652c6b3e827dc05e7a6150d9836aa1c5d808fd37bebeac8  ZuiControl-v19-system.apk
7e60f25103ec29521652c6b3e827dc05e7a6150d9836aa1c5d808fd37bebeac8  ZuiControl-v19-release.apk
```

发布只使用上述同一 CI run 的 release APK/payload。实际执行顺序是 Apply payload → 重建 `system_a.img` → `SignNoFecDryRun` → `SignNoFec` → 签名后重新 `PackSuper`。最终 `VerifyZuiControlFlashPackage.ps1` 已从成品 super 反抽全部动态分区和 system EROFS、解码成品 `services.jar`，并返回 `ok=true`。Windows 仍没有完成完整 `secilc` 编译；新包尚未刷入，因此 0.20.1 的持久 SELinux 和开机/runtime 行为仍需刷后验证，不能把静态通过写成新包实机通过。

#### 用户操作与刷后最短验证

1. 刷后先确认 PackageManager 与 `/system/priv-app/ZuiControlV30/ZuiControl.apk` 都是 30/0.20.1，旧 `/system/priv-app/ZuiControl` 不存在。
2. 刷新率：在“刷新率”页选择 App 和 60/90/120/144/165；120 表示默认并删除显式规则。QS 修改上一个真实场景，不要把 fpsCap 字段当成已交付能力。
3. P2：选择 ZUI 已识别的游戏，设置各温区后保存；必须等 UI 明确显示请求 done、XML mounted 和 reload 终态。若 ZuiPP 正在运行，终态应有 `stableSeconds=10`；若当时未运行，允许 `skipped;reason=zuipp_not_running`，首次游戏启动会读取已 bind 的 active XML。随后完全强停/退出目标游戏并重新进入。节点值是 OEM 请求结果证据，不要求瞬时严格等于输入值。
4. AppOpt：系统页添加用户 App，选择四个预设之一并等待 done；随后强停并重开目标 App。修改、删除规则或“全局停止”后也要重启目标 App，旧进程线程不会自动重建。默认 0 规则时保持 stopped。
5. 刷后检查 dmesg 与全 buffer logcat 的 AVC，并复测 P1/相机、P2 失败回滚/开机同 hash reload、AppOpt 四预设与停止。不要测试已经删除的云控/provider_direct 链。

剩余边界：P2 依赖原厂识别游戏和 GameHelper/TAssistant 链，厂商热控或更高优先级请求仍可覆盖，因而不是硬 cap；Settings.System 仍是高权限单请求槽，App 已用精确 ACK 串行化，但长期可考虑收口到签名校验 Binder；AppOpt 只交付整包 CPU 集合，不交付线程名规则。以上边界不构成本轮恢复 direct sysfs/provider 或扩大 SELinux 权限的理由。

### 0.2 2026-08-17 P2/云控重构（历史，已被 0.3 覆盖）

本节覆盖后面的旧 P2 三模式/provider 重入、云控实现、28/0.19.9 推荐包和对应验证步骤。P1 相机崩溃修复保持不变，没有进入 FPS cap。

当前目标 App 为 `versionCode=29` / `versionName=0.20.0`。本轮依据设备实测完成以下收敛：

- 云控功能删除。`/system/etc/hosts` 恢复为从官方 ZUI 16.1.11.187 `system_a.img` 抽出的 56 字节默认文件；删除 boot/property 触发、iptables 脚本、daemon cloud 目录和日志导出。升级脚本只做一次旧 setting/runtime 清理。
- 每个 package 只保存一份当前性能 profile；旧数据迁移时优先采用 `balanced`，没有 balanced 才采用第一份旧 profile。新保存统一写 canonical `balanced` 记录。
- 生成的同一份 LimitConfig 镜像到 balanced/powersave/savage 三个原厂槽位，因此不再由 daemon 猜当前 GameMode，也不存在 balanced 抢优先级。
- 每个温区的 Little/Big/Titan/Mega 使用同一个 synthetic CPU level ID（从 900000 起），但四个 Type 下分别保存该簇自己的频率值。这是针对设备实测 ZuiPP HashMap 读取顺序 `LittleCore, MegaCore, BigCore, TitanCore, GPU` 的兼容修复，避免 CPU Type/level 错配导致整条 TAssistant policy 中止。
- 删除 daemon 的 `GameModeProvider/contact` 直接调用和场景轮询。Provider 曾能返回成功但并不证明 ZuiPP 已有目标 game state，属于假成功源。
- 保存并完成 XML promote/ZuiPP 稳定重启后，用户需要退出并重新进入游戏，由原厂 `onGameAppStart` 链路应用 XML。三个模式内容相同，所以原厂选择哪个模式都得到同一配置。
- 只对 ZUI/GameHelper 已识别为游戏的应用承诺触发；给普通 App 生成 XML 条目不等于原厂会触发游戏链路。App UI 已明确提示此边界。
- CPU/GPU 是原厂性能 profile 请求，不是硬 cap。厂商热控或其他更高优先级请求仍可进一步压低或覆盖；禁止因此恢复 direct cpufreq/KGSL sysfs。
- ZuiPP reload 在新 PID 出现后连续稳定 10 秒才发布 done，若进程重启则重新计时；状态继续带 `needsAppReenter=1`。
- baked baseline 使用 payload 模板双 SHA256 版本戳；模板变化会刷新旧 baseline 并自动用保留的用户 profiles 重建 active XML，修复升级后继续沿用旧 `200 100 300` baseline 的问题。
- 正常 promote 前先备份旧 active 到 `last_good`，成功后不再用新 active 覆盖它；回滚点现在确实代表上一次配置。

针对生成器新增可执行测试 `scripts/TestXmlProfileGenerator.py`，会验证旧多模式数据只选一份、三个 OEM mode block 完全相同、四个 CPU ID 相同且各 Type 频率值正确。

#### 0.20.0 发布事实

- 生产代码 commit：`28f1f8b56628ebbaf5cdbb570fe10e1b250e5b6f`
- GitHub Actions run：`32036170577`，结论 `success`：<https://github.com/xmy953538104/ZuiControl/actions/runs/32036170577>
- 下载并用于 payload 的 CI artifact：`D:\3.VScode\Mi\work\ci_artifacts\zuicontrol_32036170577`
- CI release APK 与最终 system 内嵌 APK：`versionCode=29` / `versionName=0.20.0`
- release 证书 SHA-256：`3fecf3a72ca0e0f24991d49e7306ef4a711711f48a66070755eb0237ecb3ed94`
- 最终刷机目录：`D:\3.VScode\Mi\【B刷机】187`

```text
5fc24c5b36ba7394125b87b681b62e38575172057c78417a0fa24746815be76b  boot.img
ddfa388d1df10f6b609337af4b07ed5ca52a6d4602aebaab1ba88fec0a3970ef  super.img
9db326d3d605885c4afdac6b0883dc3f9c0bc2b9b1b3766cc4808945015967f5  vbmeta.img
16b41e21917b6f8168570ebf1d788fe8ef6ff3b2673dbc9f2fdb1a94d4b4b19a  vbmeta_system.img
66488caf0f2570770f0a6b50d3d74efded47dd172f4334c2469c996495590ee6  ZuiControl-v19-system.apk
66488caf0f2570770f0a6b50d3d74efded47dd172f4334c2469c996495590ee6  ZuiControl-v19-release.apk
```

发布只使用上述 CI release artifact。重建 `system_a.img` 后执行 `SignNoFec`，签名后重新执行 `PackSuper`。最终 verifier 从成品 `super.img` 反抽 system/vendor、解码成品 `services.jar` 并返回 `ok=true`；官方 hosts、云控脚本缺失、版本/证书、P1 注入、P2 daemon 标记和 SELinux/context 静态检查均命中。Windows 侧仍未进行 `secilc` 编译级验证，刷后必须检查真实 AVC。

这在 2026-08-17 当时仍是待刷包（历史）：当时不得把相机、P1、P2 或 AVC 写成实机通过。此后的真实结果和当前 0.20.1 待刷包以第 0.3 节为准。

### 0.1 2026-08-17 P1/AppOpt 覆盖说明（已被 0.2 的包版本覆盖）

本节记录 0.19.9 阶段的 P1/AppOpt 修复事实；其包版本、hash、旧 P2/provider、云控和下一步均已被 0.2 覆盖。P1 相机修复思路和 AppOpt 空规则门槛由 0.20.0 继续保留。

#### 设备实际状态

2026-08-17 已连接 TB321FU，ADB 已授权，`su` 可用且 SELinux 为 Enforcing。设备 App 虽然显示 `versionCode=28` / `versionName=0.19.9`，但系统内嵌 APK SHA256 是：

```text
4a6a48a92a32c64721b16b3e3069a826eed5a73918125e59260db76bad6449f6
```

它来自 2026-06-24 的旧构建，不是当时 2026-07-21 推荐包，也不是本节下面的新修复包。以后不能只用版本号判断是否刷到最新包，必须同时比较 APK 或 `super.img` hash。

旧设备上的只读检查结果：

- `zui_control` 存在；P1 状态为 `refreshOwner=system`、`daemonRefreshDisabled=true`，桌面目标和实际刷新率为 120Hz。
- P2 active XML 与 `/system/etc` 当前 bind 内容 hash 相同；鸣潮 active 条目已经是 `ThermalConfig=0 0 0`，但 system 默认模板仍是旧的 `200 100 300`，说明当前设备不是最新自动修复镜像。
- AppOpt 配置只有注释和示例，活动规则数为 0；旧 init 仍每约 5 秒重启 AppOpt，实际被 SELinux 拒绝 `dac_override` 及读取 `zui_control_data_file` 后退出。
- 已通过项目已有可逆开关执行 `setprop zui_control.appopt stop`，确认 `init.svc.zui_appopt=stopped` 且无 AppOpt PID。没有改 P1、P2 或用户 AppOpt 配置。

#### 相机导致“重启”的已确认根因

`/data/tombstones` 中至少有两组 2026-06-30 的相同崩溃链。真正先崩的是 SurfaceFlinger，不是相机：

```text
No matching frame rate modes for primary range.
physical=[120.00 Hz, 120.00 Hz]
render=[30.00 Hz, 60.00 Hz]
```

调用栈位于：

```text
RefreshRateSelector::constructAvailableRefreshRates
-> RefreshRateSelector::setPolicy
-> SurfaceFlinger::setDesiredDisplayModeSpecsInternal
-> abort
```

随后 CameraProvider 因 SurfaceFlinger Binder 死亡而以 `DEAD_OBJECT` 退出。因此“打开相机就重启”是 P1 刷新率硬投票制造无交集策略导致的系统图形栈崩溃，相机只是触发了 30–60 FPS 的合法约束。其他会提出不同渲染区间的 App 也可能触发同类问题。

旧实现还存在两个结构性问题：

1. 在优先级 8（ZUI 名称实际是 `PRIORITY_AUTH_OPTIMIZER_RENDER_FRAME_RATE`）写入了 `Vote.forPhysicalRefreshRates(hz, hz)`，投票类型与优先级语义不匹配。
2. `DisplayContent.setFocusedApp` 的同步 hook 直接执行 profile、Settings、反射和显示服务调用，违反焦点路径只能轻量上报事件的规则，也解释了除刷新率表面切换外其他联动显得慢和不稳定。

#### 2026-08-17 P1/AppOpt 修复

代码提交：

```text
61a4b26 Fix refresh vote crash and gate empty AppOpt
```

P1 只做根因级最小修复，没有进入 FPS cap：

- 删除 `forPhysicalRefreshRates(hz, hz)` 和 GameHelper 十秒 yield 补丁逻辑。
- 统一使用 `Vote.forRenderFrameRates(0, targetHz)`，配合 ROM 的目标 mode 和 `max=targetHz`；允许相机/视频的 30–60 render 约束与 120Hz 物理显示共存。
- `onFocusedAppChanged` 只提取 package/uid/user/display 原始值并投递到独立 `HandlerThread("ZuiControl")`；profile I/O、Settings、反射和 apply 不再阻塞 WM 焦点关键路径。
- 状态新增 `displayVote=adaptiveRender`。

稳定性优先带来的明确边界：新策略是“目标 mode + render 上限/偏好”，不再承诺在所有相机、视频、热控或系统冲突场景中物理面板绝对硬锁。60/90/120/144/165 的真实 active mode 仍需刷后逐项验证。

AppOpt 当前没有源码和 UI 规则编辑器，不应冒充完整交付。新包的默认行为改为：

- boot completed 只准备配置，不再无条件 `start zui_appopt`。
- daemon 统计有效 `key=value` 规则；0 条规则时拒绝启动、清理 enabled 标记并发布明确状态。
- 有规则时启动后必须连续确认 init 状态为 running 且 PID 存在，失败则停止服务并清理 enabled 标记。
- 外部兼容命令仍叫 `apply_asoul` / `restore_asoul`，内部实际函数和状态统一按 AppOpt 命名；不恢复旧 AsoulOpt。

#### 2026-08-17 当时待刷包（历史）

GitHub Actions：

```text
run_id=32013336830
workflow=Build ZuiControl
head=61a4b2622d7579036fdd2a7b04faa8983986bccc
status=success
artifact_dir=D:\3.VScode\Mi\work\ci_artifacts\zuicontrol_32013336830
package=com.zui.zuicontrol
versionCode=28
versionName=0.19.9
release_cert_sha256=3fecf3a72ca0e0f24991d49e7306ef4a711711f48a66070755eb0237ecb3ed94
```

最终刷机目录：

```text
D:\3.VScode\Mi\【B刷机】187
```

最终 SHA256：

```text
5fc24c5b36ba7394125b87b681b62e38575172057c78417a0fa24746815be76b  boot.img
34de9656be5f7473ffef6ec81070a8c5a409b3ad6a18af9a715eebed290adf2d  super.img
9db326d3d605885c4afdac6b0883dc3f9c0bc2b9b1b3766cc4808945015967f5  vbmeta.img
6d5bc0db0d9ed46aeef05b25c58b496e93e8569980189dbdd40af0b0aa1eab6f  vbmeta_system.img
3f6f09ca6452cd8b881fdd1ebf335405b9a1e9d8ad126783107d5f2f70113e5c  ZuiControl-v19-system.apk
3f6f09ca6452cd8b881fdd1ebf335405b9a1e9d8ad126783107d5f2f70113e5c  ZuiControl-v19-release.apk
```

发布过程只使用上述 CI release APK/payload；重建 `system_a` 后执行 `SignNoFec`，签名后重新执行 `PackSuper`。最终 verifier 已从成品 `super.img` 反抽 system/vendor 并得到 `ok=true`，还解码了成品 `services.jar`，确认：

- 存在 `HandlerThread`、`forRenderFrameRates`、`displayVote=adaptiveRender`。
- 不存在 `forPhysicalRefreshRates`。
- AppOpt init 不再无条件启动，daemon 含 0 规则门槛。
- APK 内嵌/两个 sidecar hash 一致，版本为 28/0.19.9 且为 release 签名。
- P2 鸣潮模板仍为 `ThermalConfig=0 0 0`，XML 五段引用、SELinux/context 和无 direct CPU/GPU sysfs 规则继续通过。

#### 2026-08-17 当时的下一步（历史）

新包尚未刷到真实设备，不能把“最终镜像静态通过”写成“相机问题实机已修复”。下一步只刷上述 hash 的包，然后按以下顺序验证：

1. 先比较设备 `/system/priv-app/ZuiControl/ZuiControl.apk` SHA256 必须为 `3f6f09...13e5c`，再确认 28/0.19.9。
2. 开机稳定性：确认 SystemUI/SurfaceFlinger/system_server 无崩溃循环，`zui_control` 存在，状态含 `displayVote=adaptiveRender`、`refreshOwner=system`、`daemonRefreshDisabled=true`。
3. P1：桌面和多个普通 App 默认 120；分别保存并测试 60/90/120/144/165，观察 target、actual active mode 和重复 apply 防抖。
4. 相机：先打开系统相机，再从第三方 App 调用相机；全程同步抓 SurfaceFlinger/CameraProvider tombstone、logcat 和 active mode，确认没有 `No matching frame rate modes`。
5. QS/SystemUI：下拉 QS 修改上一个真实场景，确认不会生成 SystemUI profile。
6. AppOpt：默认 0 规则时应为 stopped 且无重启/AVC；只有写入真实有效规则并明确启用后才应 running。由于暂无 UI 编辑器和源代码，先只验证门槛和稳定性，不宣称调度效果已交付。
7. P2：核对 active XML 与 `/system/etc` hash、鸣潮 `ThermalConfig=0 0 0`；进入、退出、再进入鸣潮，provider_direct 时间戳每次更新，并结合 ZuiPP/Thermal/KGSL 日志判断实际应用。
8. 云控：核对 hosts、iptables/ip6tables 独立 UID 规则，确认无 UID1000 全断规则。
9. AVC：检查 zui_control、system_server、AppOpt/performanced、shell/init、ZuiPP 和云控相关 denial。

上述验证通过前，不再改 P1，不进入 FPS cap，不恢复 direct CPU/GPU sysfs，也不重新引入旧 AsoulOpt。

> **历史区提示：** 以下第 1～8 节保留 2026-07-21/0.19.9 的调查证据和旧实现说明。凡涉及当前包、P2 三模式/provider、云控或下一步，不得直接执行，必须以第 0.3 节为准。

## 1. 2026-07-21 历史快照

```text
工作区：D:\3.VScode\Mi
当前 App 仓库：D:\3.VScode\Mi\ZuiControl
历史旧仓库：D:\3.VScode\Mi\ZuiperfCtl（不要作为当前代码入口）
设备/系统：TB321FU / ZUI 16.1.11.187
分支：main
remote：git@github.com:xmy953538104/ZuiControl.git
仓库交接前 HEAD：7195c2651eb38da9b3fecd7178298be7957e0092
当前 App：versionCode=28 / versionName=0.19.9
```

2026-07-21 整理交接时设备未连接，因此本文件没有把 2026-06-24 的最终镜像冒充成“已经刷后验证通过”。最新镜像已完成本地构建、签名、PackSuper 和 final super 反抽验证；刷后实机状态仍需新窗口重新确认。

## 2. 历史刷机包（已被 0.20.0 替代）

目录：

```text
D:\3.VScode\Mi\【B刷机】187
```

最新功能代码提交：

```text
6e698a1 Fix Mingchao XML thermal application
```

后续文档提交：

```text
7195c26 Document Mingchao XML thermal fix
```

GitHub Actions：

```text
run_id=28089289333
workflow=Build ZuiControl
head=6e698a1693e64e457c66e289a7ab032149e0fd5e
status=success
artifact_dir=D:\3.VScode\Mi\work\ci_artifacts\zuicontrol_28089289333
```

APK：

```text
package=com.zui.zuicontrol
versionCode=28
versionName=0.19.9
release cert SHA-256=3fecf3a72ca0e0f24991d49e7306ef4a711711f48a66070755eb0237ecb3ed94
```

最终 SHA256：

```text
5fc24c5b36ba7394125b87b681b62e38575172057c78417a0fa24746815be76b  boot.img
4d0d7fe55d8ed37d7fbf1220a39c3baed6631c77e5d5955b61f3936d3eb4f82d  super.img
9db326d3d605885c4afdac6b0883dc3f9c0bc2b9b1b3766cc4808945015967f5  vbmeta.img
f3caa64f53a130ddafcf31d09e03c5ad9d33988ccc318ba0c6b7df5d0d364762  vbmeta_system.img
89293b21225588e5b9ae8c6d4cec1d8b99b6b89fbdde07a6564cd234bb426aea  ZuiControl-v19-system.apk
89293b21225588e5b9ae8c6d4cec1d8b99b6b89fbdde07a6564cd234bb426aea  ZuiControl-v19-release.apk
```

最终验证：

```text
VerifyZuiControlFlashPackage.ps1 -FlashDir "D:\3.VScode\Mi\【B刷机】187"
ok=true
```

验证器已从最终 `super.img` 反抽真实 system/vendor 内容，不只是检查源码或 `work/unpack`。

## 3. P1 刷新率状态

P1 已经完成 system_server ownership 迁移并经过旧包实机验证。本轮交接没有修改 P1。

主链路：

```text
DisplayContent.setFocusedApp(ActivityRecord)
-> ZuiControlHooks.onFocusedAppChanged(record, displayId)
-> ZuiControlService
-> /data/system/zui_control/profiles.prop + 内存 profile
-> DisplayManagerInternal display vote
-> active display mode
```

必须保持：

- `system_server` 是唯一刷新率 owner。
- 未配置场景默认 120Hz。
- QS 修改 `lastNonTransientScenePackage`，不能学习 SystemUI。
- daemon 不恢复 `refresh_tick`、`learn_refresh`、peak/min settings 抢写或开机强写 120。
- v19 只承诺 displayHz lock，不把 FPS cap 当作已交付能力。

## 4. P2 XML 当前实现

生产主链路：

```text
ZuiControl 保存性能 profile
-> zui_controld 写 /data/vendor/zui_control/performance/profiles.prop
-> XmlProfileGenerator 生成 staging game_policy.xml/performanceconfig.xml
-> 校验并 promote 到 /data/vendor/zui_control/zuipp/active/
-> bind mount 到 /system/etc/game_policy.xml 和 performanceconfig.xml
-> hash 闭合后受控 reload com.zui.pp
-> system_server 场景事件进入目标 App
-> daemon 直接 content update ZuiPP GameModeProvider/contact
-> ZuiPP 按当前 gameMode 重新应用 XML LimitConfig
```

边界：

- CPU/GPU 都走 XML + ZuiPP/GameHelper 原厂链路。
- daemon 不生产直写 CPU cpufreq 或 KGSL GPU sysfs。
- `balanced=0`、`powersave=1`、`savage=2`。
- 每次重新进入有 profile 的 App，`apply_pp_mode_for_scene "$top" force` 重发一次 provider；不常驻轮询。

### 鸣潮最新修复

鸣潮包名：

```text
com.kurogame.mingchao
```

已确认旧问题不是 XML 没生成或 bind mount 失败。ZuiPP 已读到用户 `LimitConfig`，但同一 App 条目的 `ThermalConfig=200 100 300` 会选择 vendor thermal user case；现场 `200 -> battery_2/gpu_0` 后，KGSL 曾被压到约 `thermal_pwrlevel=10`、`max_gpuclk=310000000`。

当前修复：

- `XmlProfileGenerator` 对用户生成的独立游戏条目统一写 `ThermalConfig=0 0 0`。
- 默认模板中鸣潮条目也是 `ThermalConfig=0 0 0`。
- 这只避免主动切到 100/200/300 游戏热控 user case，不关闭系统全局过热保护。
- final verifier 会拒绝鸣潮模板不是 `0 0 0` 的刷机包。

2026-06-24 现场临时验证：改为 `0 0 0` 并 reload 后，观察到 `thermal_pwrlevel=0`、`max_gpuclk=903000000`。这证明旧 user case 是冲突源，但最终 2026-06-24 镜像仍需刷后重新验证完整自动链路。

## 5. P3 线程放置当前实现

AGENTS.md 把产品功能称为 `asoulOpt` 线程放置/亲合度模块；当前实际系统后端已经替换为 AppOpt。新窗口必须区分“功能名/兼容命令名”和“真实运行二进制”。

当前真实后端：

```text
/system/bin/AppOpt
/system/etc/init/zui_appopt.rc
/system/etc/zui_control/default_applist.conf
/system/etc/zui_control/zui_appopt_prepare.sh
/data/vendor/zui_control/appopt/applist.conf
service=zui_appopt
```

已从镜像删除旧项：

```text
/system/bin/AsoulOpt
/system/etc/asopt.conf
/system/etc/init/zui_asoulopt.rc
/system/etc/zui_control/asopt.conf
/system/etc/zui_control/default_asopt.conf
/system/etc/zui_control/zui_asoulopt.sh
```

兼容遗留：

- daemon 请求名仍有 `apply_asoul` / `restore_asoul`，实际操作 AppOpt。
- UI 仍有 `AsoulOpt` 文案，状态正文会显示“后端：AppOpt”。
- `zui_appopt_prepare.sh` 会清理可能残留的旧 `AsoulOpt` 进程。
- 不要因为兼容名字重新把旧 AsoulOpt 二进制和三份 conf 加回来。

当前 SELinux 修复：

- `/system/bin/AppOpt` 标记为 `performanced_exec`。
- `performanced` 获得读取 `/data/vendor/zui_control/appopt/applist.conf` 所需的目录/file 权限和 `dac_override`。
- Windows 侧没有 `secilc` 完整编译验证，刷后仍必须检查 AVC。

## 6. 云控屏蔽历史实现（0.20.0 已删除）

当前不再一刀切 UID1000，也不冻结 `com.zui.pp`。

两层实现：

1. `/system/etc/hosts` 静态屏蔽已知 Lenovo/ZUI 云控域名。
2. `zui_cloud_block.sh` 用 iptables/ip6tables 阻断少数独立 UID 云控包。

独立 UID 目标包括：

```text
com.zui.game.service
com.zui.engine
com.lenovo.tbengine
com.lenovo.leos.cloud.sync
com.tblenovo.tabpushout
com.tblenovo.center
```

明确边界：

- 不含 `--uid-owner 1000`。
- `com.zui.pp`、`com.zui.cores`、`com.zui.safecenter` 不被共享 UID 一刀切。
- hosts 是静态规则，不做后台抓包或持续网络扫描。
- hosts 只匹配明确域名，不支持通配所有未来子域名或硬编码 IP。

## 7. 0.19.9 历史验证步骤（不要用于 0.20.0）

先确认设备是否已经刷入上述最终包，再做刷后验证。2026-07-21 当前设备未连接，不能跳过这一步。

连接设备后先运行：

```powershell
$adb = "D:\3.VScode\Mi\tools\adb\adb.exe"
& $adb get-state
& $adb shell su -c id
& $adb shell dumpsys package com.zui.zuicontrol | findstr "versionCode versionName"
& $adb shell service list | findstr zui_control
& $adb shell dumpsys zui_control
```

预期 App 为 `28 / 0.19.9`。如果不是，不要拿旧包状态判断新修复，应先刷 `D:\3.VScode\Mi\【B刷机】187`。

刷后按顺序验证：

1. P1：`zui_control` 存在，`refreshOwner=system`，`daemonRefreshDisabled=true`，场景切换仍正常。
2. P3：`init.svc.zui_appopt=running`，`pidof AppOpt` 有 PID，配置可读，无 AppOpt/performanced AVC。
3. 云控：状态键、hosts 和 iptables/ip6tables 链存在，确认没有 UID1000 全断规则。
4. P2：active XML 与 `/system/etc` hash 一致，鸣潮条目 `ThermalConfig=0 0 0`。
5. 进入鸣潮：`zui_control_pp_mode_state` 更新为当前时间、`state=triggered;stage=provider_direct;package=com.kurogame.mingchao;mode=0;xml=...`。
6. 退出再进鸣潮：时间戳再次更新，证明 scene-enter force retrigger 生效。
7. 读取 ZuiPP/Thermal/KGSL 日志和节点，区分 XML 没应用、vendor user case 限制和真实高温全局降频。
8. 检查 `dmesg/logcat` 中与 zui_control、AppOpt、cloud block、ZuiPP 相关的 AVC。

未完成上述刷后验证前：

- 不进入 FPS cap。
- 不修改 P1。
- 不恢复 direct CPU/GPU sysfs。
- 不重新引入旧 AsoulOpt 二进制/conf。
- 不根据旧 0.19.8/P2-I 文档判断当前 0.19.9 包。

## 8. 关键代码入口

```text
P1 system_server:
ZuiControl/framework_patch/src/services/com/zui/server/control/ZuiControlService.java
ZuiControl/framework_patch/src/services/com/zui/server/control/ZuiControlHooks.java

P2:
ZuiControl/app/src/main/java/com/zui/zuicontrol/XmlProfileGenerator.java
ZuiControl/app/src/main/java/com/zui/zuicontrol/PerformanceProfile.kt
ZuiControl/payload/system/bin/zui_controld
ZuiControl/payload/system/etc/zui_control/default_game_policy.xml
ZuiControl/payload/system/etc/zui_control/default_performanceconfig.xml

P3/AppOpt:
ZuiControl/payload/system/bin/AppOpt
ZuiControl/payload/system/etc/init/zui_appopt.rc
ZuiControl/payload/system/etc/zui_control/zui_appopt_prepare.sh
ZuiControl/payload/system/etc/zui_control/default_applist.conf

云控已删除；只保留官方默认文件：
ZuiControl/payload/system/etc/hosts

打包/验证：
ZuiControl/scripts/ApplyZuiControlPayload.py
ZuiControl/scripts/VerifyZuiControlFlashPackage.ps1
```

## 9. 新聊天首条消息

本节原先保存过旧版复制文本，现已作废。新聊天不要复制历史段落；直接使用同目录的 `AI交接记录_ZuiControl_2026-07-21_当前主入口.txt`，它与本文第 0.18 节保持一致。
