#!/usr/bin/env python3
import argparse
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys
from datetime import datetime


APP_PACKAGE = "com.zui.zuicontrol"
LEGACY_APP_PACKAGE = "com.zui.zuiperfctl"
APP_APK_PATH = "system/priv-app/ZuiControlV49/ZuiControl.apk"
LEGACY_APP_PAYLOAD_PATH = "system/priv-app/ZuiControl"

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def stamp():
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def resolve_root():
    return pathlib.Path(__file__).resolve().parents[1]


def resolve_unpack(root, unpack_arg):
    candidates = []
    if unpack_arg:
        candidates.append(pathlib.Path(unpack_arg))
    candidates.append(root / "work" / "unpack")
    candidates.append(root.parent / "work" / "unpack")
    for candidate in candidates:
        candidate = candidate.expanduser().resolve()
        if any((candidate / name).exists() for name in ["system_a", "vendor_a", "product_a", "odm_a"]):
            return candidate
    raise SystemExit("Cannot find unpack root. Expected work/unpack with system_a.")


def resolve_image_root(root, unpack):
    unpack = pathlib.Path(unpack).resolve()
    if unpack.name == "unpack" and unpack.parent.name == "work":
        return unpack.parent.parent
    return root


def ensure_line(path, key, line, changed, dry_run):
    path = pathlib.Path(path)
    lines = []
    if path.exists():
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
    kept = [item for item in lines if first_field(item) != key]
    if line in kept:
        return
    kept.append(line)
    changed.append(str(path))
    if dry_run:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(kept) + "\n", encoding="utf-8")


def first_field(line):
    parts = line.split()
    return parts[0] if parts else ""


def file_context_regex(path):
    return "/" + path.replace("\\", "/").replace(".", r"\.")


def mode_for(rel, is_dir):
    if is_dir:
        return "0755"
    if rel in [
        "system_a/system/bin/zui_controld",
        "system_a/system/bin/zui_uperf_service",
        "system_a/system/bin/uperf",
        "system_a/system/bin/AsoulOpt",
    ]:
        return "0755"
    return "0644"


def owner_group_for(rel):
    if rel in [
        "system_a/system/bin/zui_uperf_service",
        "system_a/system/bin/uperf",
        "system_a/system/bin/AsoulOpt",
    ]:
        return "0 2000"
    return "0 0"


def context_for(rel):
    if rel in [
        "system_a/system/bin/zui_uperf_service",
        "system_a/system/bin/uperf",
        "system_a/system/bin/AsoulOpt",
    ]:
        return "u:object_r:performanced_exec:s0"
    return "u:object_r:system_file:s0"


def remove_path(path, dry_run, removed):
    path = pathlib.Path(path)
    if not path.exists():
        return
    removed.append(str(path))
    if dry_run:
        return
    if path.is_dir():
        shutil.rmtree(path)
    else:
        path.unlink()


def remove_lines_containing(path, needles, dry_run):
    path = pathlib.Path(path)
    if not path.exists():
        return []
    lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
    kept = [line for line in lines if not any(needle in line for needle in needles)]
    removed = [line for line in lines if any(needle in line for needle in needles)]
    if removed and not dry_run:
        path.write_text("\n".join(kept) + "\n", encoding="utf-8")
    return removed


def cleanup_legacy_payload(unpack, dry_run, report):
    removed = []
    legacy = [
        "system_a/system/priv-app/ZuiControl",
        "system_a/system/priv-app/ZuiControlV30",
        "system_a/system/priv-app/ZuiControlV31",
        "system_a/system/priv-app/ZuiControlV32",
        "system_a/system/priv-app/ZuiControlV33",
        "system_a/system/priv-app/ZuiControlV34",
        "system_a/system/priv-app/ZuiControlV35",
        "system_a/system/priv-app/ZuiControlV36",
        "system_a/system/priv-app/ZuiControlV37",
        "system_a/system/priv-app/ZuiControlV38",
        "system_a/system/priv-app/ZuiControlV39",
        "system_a/system/priv-app/ZuiControlV40",
        "system_a/system/priv-app/ZuiControlV41",
        "system_a/system/priv-app/ZuiControlV42",
        "system_a/system/priv-app/ZuiControlV43",
        "system_a/system/priv-app/ZuiControlV44",
        "system_a/system/priv-app/ZuiControlV45",
        "system_a/system/priv-app/ZuiControlV46",
        "system_a/system/priv-app/ZuiControlV47",
        "system_a/system/priv-app/ZuiControlV48",
        "system_a/system/priv-app/ZuiperfCtl",
        "system_a/system/bin/zui_perfctld",
        "system_a/system/etc/init/zui_perfctld.rc",
        "system_a/system/etc/zui_perfctl",
        "system_a/system/etc/permissions/privapp-permissions-zui-perfctl.xml",
        "system_a/system/etc/default-permissions/default-permissions-zui-zuiperfctl.xml",
        "system_a/system/bin/AsoulOpt",
        "system_a/system/etc/init/zui_asoulopt.rc",
        "system_a/system/etc/zui_control/zui_asoulopt.sh",
        "system_a/system/etc/zui_control/default_asopt.conf",
        "system_a/system/etc/zui_control/asopt.conf",
        "system_a/system/etc/asopt.conf",
        "system_a/system/etc/zui_control/zui_cloud_block.sh",
        "system_a/system/etc/zui_control/clear_package_cache.sh",
        "system_a/system/bin/AppOpt",
        "system_a/system/bin/AppOpt-ebpf",
        "system_a/system/etc/init/zui_appopt.rc",
        "system_a/system/etc/zui_control/AppOpt.json",
        "system_a/system/etc/zui_control/default_applist.conf",
        "system_a/system/etc/zui_control/zui_appopt_prepare.sh",
        "system_a/system/etc/zui_control/promote_zuipp_xml.sh",
        "system_a/AppOpt.json",
        "system_a/system/preinstall/QQMusic",
    ]
    for rel in legacy:
        remove_path(unpack / rel, dry_run, removed)
    report["legacy_removed"] = removed


def cleanup_legacy_metadata(image_root, unpack, dry_run, report):
    needles = [
        "zui_perfctl",
        "zui_perfctld",
        "ZuiperfCtl",
        "zuiperfctl",
        "zui-perfctl",
        "AsoulOpt",
        "zui_asoulopt",
        "asopt.conf",
        "/data/adb/naki",
        "zui_cloud_block",
        "AppOpt",
        "zui_appopt",
        "default_applist.conf",
        "system_a/system/priv-app/ZuiControl ",
        "system_a/system/priv-app/ZuiControl/ZuiControl",
        "system_a/system/priv-app/ZuiControlV30",
        "system_a/system/priv-app/ZuiControlV31",
        "system_a/system/priv-app/ZuiControlV32",
        "system_a/system/priv-app/ZuiControlV33",
        "system_a/system/priv-app/ZuiControlV34",
        "system_a/system/priv-app/ZuiControlV35",
        "system_a/system/priv-app/ZuiControlV36",
        "system_a/system/priv-app/ZuiControlV37",
        "system_a/system/priv-app/ZuiControlV38",
        "system_a/system/priv-app/ZuiControlV39",
        "system_a/system/priv-app/ZuiControlV40",
        "system_a/system/priv-app/ZuiControlV41",
        "system_a/system/priv-app/ZuiControlV42",
        "system_a/system/priv-app/ZuiControlV43",
        "system_a/system/priv-app/ZuiControlV44",
        "system_a/system/priv-app/ZuiControlV45",
        "system_a/system/priv-app/ZuiControlV46",
        "system_a/system/priv-app/ZuiControlV47",
        "system_a/system/priv-app/ZuiControlV48",
        "system_a/system/etc/zui_control/clear_package_cache",
        "system_a/system/preinstall/QQMusic",
    ]
    targets = [
        unpack / "config" / "system_a_fs_config",
        unpack / "config" / "system_a_file_contexts",
        image_root / "work" / "config" / "erofs_overrides" / "system_a_fs_config",
        image_root / "work" / "config" / "erofs_overrides" / "system_a_file_contexts",
        unpack / "system_a" / "system" / "etc" / "selinux" / "plat_property_contexts",
        unpack / "system_a" / "system" / "etc" / "selinux" / "plat_service_contexts",
        unpack / "system_a" / "system" / "etc" / "selinux" / "plat_file_contexts",
        unpack / "system_a" / "system" / "etc" / "selinux" / "plat_sepolicy.cil",
        unpack / "vendor_a" / "etc" / "selinux" / "vendor_sepolicy.cil",
    ]
    removed = {}
    for target in targets:
        lines = remove_lines_containing(target, needles, dry_run)
        if lines:
            removed[str(target)] = lines
    report["legacy_metadata_removed"] = removed


def copy_payload(payload, unpack, dry_run, report):
    copied = []
    metadata = []
    dst_items = []
    for src in sorted(payload.rglob("*")):
        rel_payload = src.relative_to(payload).as_posix()
        if not rel_payload.startswith("system/"):
            continue
        if rel_payload == LEGACY_APP_PAYLOAD_PATH or rel_payload.startswith(LEGACY_APP_PAYLOAD_PATH + "/"):
            continue
        dst_rel = f"system_a/{rel_payload}"
        dst = unpack / dst_rel
        mode = int(mode_for(dst_rel, src.is_dir()), 8)
        dst_items.append((dst_rel, src.is_dir()))
        if src.is_dir():
            if not dry_run:
                dst.mkdir(parents=True, exist_ok=True)
                try:
                    dst.chmod(mode)
                except OSError:
                    pass
            copied.append({"source": str(src), "target": dst_rel, "directory": True})
            continue
        changed = True
        if dst.exists() and dst.is_file():
            changed = src.read_bytes() != dst.read_bytes()
        copied.append({"source": str(src), "target": dst_rel, "changed": changed})
        if not dry_run:
            dst.parent.mkdir(parents=True, exist_ok=True)
            if changed:
                shutil.copy2(src, dst)
            try:
                dst.chmod(mode)
            except OSError:
                pass

    for rel, is_dir in dst_items:
        mode = mode_for(rel, is_dir)
        metadata.append(("fs", "system_a", rel, f"{rel} {owner_group_for(rel)} {mode}"))
        metadata.append(("ctx", "system_a", file_context_regex(rel), f"{file_context_regex(rel)} {context_for(rel)}"))

    report["copied"] = copied
    report["metadata_entries"] = len(metadata)
    return metadata


def update_metadata(root, unpack, entries, dry_run, report):
    changed = []
    for kind, base, key, line in entries:
        suffix = "_fs_config" if kind == "fs" else "_file_contexts"
        ensure_line(unpack / "config" / f"{base}{suffix}", key, line, changed, dry_run)
        ensure_line(root / "work" / "config" / "erofs_overrides" / f"{base}{suffix}", key, line, changed, dry_run)
    report["metadata_files"] = changed


def cleanup_retired_whitelists(unpack, dry_run, report):
    base = unpack / "system_a" / "system" / "etc"
    targets = [
        base / "ZuiMemCleanerConfig.xml",
        base / "ZuiPowerPolicyConfig.xml",
        base / "motorola" / "bgintents" / "com.zui.safecenter.autorun.xml",
        base / "zuipp_powercfg.xml",
    ]
    changed = []
    for path in targets:
        if not path.exists():
            continue
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        kept = [
            line for line in lines
            if APP_PACKAGE not in line and LEGACY_APP_PACKAGE not in line
        ]
        if kept != lines:
            changed.append(str(path))
            if not dry_run:
                path.write_text("\n".join(kept) + "\n", encoding="utf-8")
    report["retired_whitelists_removed"] = changed


def read_patch_lines(path):
    if not path.exists():
        return []
    return [
        line.rstrip("\n").lstrip("\ufeff")
        for line in path.read_text(encoding="utf-8", errors="ignore").splitlines()
        if line.strip()
    ]


def append_unique_lines(target, lines, dry_run):
    if not lines:
        return []
    target = pathlib.Path(target)
    current = []
    if target.exists():
        current = target.read_text(encoding="utf-8", errors="ignore").splitlines()
    additions = [line for line in lines if line not in current]
    if additions and not dry_run:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("\n".join(current + additions) + "\n", encoding="utf-8")
    return additions


def merge_unique_lines_by_key(target, lines, dry_run):
    if not lines:
        return [], False
    target = pathlib.Path(target)
    current = []
    if target.exists():
        current = target.read_text(encoding="utf-8", errors="ignore").splitlines()
    keys = {first_field(line) for line in lines}
    kept = [line for line in current if first_field(line) not in keys]
    updated = kept + lines
    additions = [line for line in lines if line not in current]
    changed = updated != current
    if changed and not dry_run:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("\n".join(updated) + "\n", encoding="utf-8")
    return additions, changed


def patch_property_contexts(unpack, payload, dry_run, report):
    patch = payload / "patches" / "plat_property_contexts_add.txt"
    target = unpack / "system_a" / "system" / "etc" / "selinux" / "plat_property_contexts"
    additions = append_unique_lines(target, read_patch_lines(patch), dry_run)
    report["property_contexts_added"] = additions


def patch_service_contexts(unpack, payload, dry_run, report):
    patch = payload / "patches" / "plat_service_contexts_add.txt"
    target = unpack / "system_a" / "system" / "etc" / "selinux" / "plat_service_contexts"
    additions = append_unique_lines(target, read_patch_lines(patch), dry_run)
    report["service_contexts_added"] = additions


def patch_file_contexts(unpack, payload, dry_run, report):
    patch = payload / "patches" / "plat_file_contexts_add.txt"
    target = unpack / "system_a" / "system" / "etc" / "selinux" / "plat_file_contexts"
    removed = remove_lines_containing(target, [
        "/data/vendor/zui_control/zuipp/active/game_policy\\.xml",
        "/data/vendor/zui_control/zuipp/active/performanceconfig\\.xml",
    ], dry_run)
    additions, changed = merge_unique_lines_by_key(target, read_patch_lines(patch), dry_run)
    report["file_contexts_removed"] = removed
    report["file_contexts_added"] = additions
    report["file_contexts_reordered_or_replaced"] = changed


def patch_plat_sepolicy(unpack, payload, dry_run, report):
    patch = payload / "patches" / "plat_sepolicy_zui_control.cil"
    target = unpack / "system_a" / "system" / "etc" / "selinux" / "plat_sepolicy.cil"
    obsolete = [
        ";; P2 XML reload only signals ZuiPP/GameHelper after active XML is remounted.",
        "(allow shell self (capability (kill)))",
        "(allow shell system_app (process (signal sigkill)))",
        "(allow shell platform_app (process (signal sigkill)))",
        "(allow init shell_data_file (dir (getattr open read search write add_name remove_name)))",
        "(allow init shell_data_file (file (getattr open read write create unlink setattr relabelfrom)))",
        "(allow performanced adb_data_file (dir (search)))",
    ]
    removed = remove_lines_containing(target, obsolete, dry_run)
    patch_lines = read_patch_lines(patch)
    additions = append_unique_lines(target, patch_lines, dry_run)
    report["plat_sepolicy_removed"] = removed
    report["plat_sepolicy_added"] = additions
    if (patch_lines or removed) and not dry_run:
        update_plat_mapping_hash(unpack, report)


def patch_vendor_sepolicy(unpack, payload, dry_run, report):
    target = unpack / "vendor_a" / "etc" / "selinux" / "vendor_sepolicy.cil"
    obsolete = [
        ";; Allow the root shell-domain daemon to enforce KGSL GPU limits.",
        ";; The daemon writes max_pwrlevel/min_pwrlevel only when a foreground app has",
        ";; an explicit ZuiControl performance profile.",
        "(allow shell_34_0 vendor_sysfs_kgsl (dir ",
        "(allow shell_34_0 vendor_sysfs_kgsl (file ",
        "(allow shell_34_0 vendor_sysfs_kgsl (lnk_file ",
        "(allow performanced_34_0 vendor_sysfs_kgsl (dir ",
        "(allow performanced_34_0 vendor_sysfs_kgsl (file ",
        "(allow performanced_34_0 vendor_sysfs_kgsl (lnk_file ",
    ]
    removed = remove_lines_containing(target, obsolete, dry_run)
    patch = payload / "patches" / "vendor_sepolicy_zui_scheduler.cil"
    additions = append_unique_lines(target, read_patch_lines(patch), dry_run)
    report["vendor_sepolicy_removed"] = removed
    report["vendor_sepolicy_added"] = additions


def update_plat_mapping_hash(unpack, report):
    sepolicy_dir = unpack / "system_a" / "system" / "etc" / "selinux"
    plat = sepolicy_dir / "plat_sepolicy.cil"
    mapping = sepolicy_dir / "mapping" / "34.0.cil"
    sha_file = sepolicy_dir / "plat_sepolicy_and_mapping.sha256"
    digest = hashlib.sha256(plat.read_bytes() + mapping.read_bytes()).hexdigest()
    old = sha_file.read_text(encoding="utf-8", errors="ignore").strip() if sha_file.exists() else ""
    sha_file.write_text(digest + "\n", encoding="utf-8")
    report["plat_sepolicy_and_mapping_sha256"] = {
        "old": old,
        "new": digest,
        "odm_precompiled_hash_left_unchanged": True,
        "reason": "Force Android init to compile split sepolicy with /system/bin/secilc on boot.",
    }


def patch_framework_jars(root, unpack, dry_run, report):
    script = root / "scripts" / "PatchZuiControlFramework.py"
    if not script.exists():
        report["warnings"].append(f"missing framework patch script: {script}")
        return
    cmd = [sys.executable, str(script), "--unpack", str(unpack)]
    if dry_run:
        cmd.append("--dry-run")
    subprocess.run(cmd, check=True)
    report["framework_patch"] = "applied"


def main():
    parser = argparse.ArgumentParser(description="Apply ZuiControl payload into an unpacked image tree.")
    parser.add_argument("--root", help="Project root containing work/config, default: this repository root")
    parser.add_argument("--unpack", help="Unpacked image root, default: work/unpack")
    parser.add_argument("--payload", help="Payload root, default: payload")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    root = pathlib.Path(args.root).resolve() if args.root else resolve_root()
    unpack = resolve_unpack(root, args.unpack)
    image_root = resolve_image_root(root, unpack)
    payload = pathlib.Path(args.payload).resolve() if args.payload else root / "payload"
    if not payload.exists():
        raise SystemExit(f"Missing payload: {payload}")

    report = {
        "started_at": datetime.now().isoformat(timespec="seconds"),
        "root": str(root),
        "image_root": str(image_root),
        "unpack": str(unpack),
        "payload": str(payload),
        "dry_run": args.dry_run,
        "warnings": [],
    }
    apk = payload.joinpath(*APP_APK_PATH.split("/"))
    if not apk.exists():
        raise SystemExit(f"Missing {APP_APK_PATH}. Run scripts/BuildZuiControl.ps1 before applying the payload.")

    cleanup_legacy_payload(unpack, args.dry_run, report)
    cleanup_legacy_metadata(image_root, unpack, args.dry_run, report)
    entries = copy_payload(payload, unpack, args.dry_run, report)
    cleanup_retired_whitelists(unpack, args.dry_run, report)
    dumpsys_rel = "system_a/system/bin/dumpsys"
    entries.append((
        "ctx",
        "system_a",
        file_context_regex(dumpsys_rel),
        f"{file_context_regex(dumpsys_rel)} u:object_r:toolbox_exec:s0",
    ))
    patch_property_contexts(unpack, payload, args.dry_run, report)
    patch_service_contexts(unpack, payload, args.dry_run, report)
    patch_file_contexts(unpack, payload, args.dry_run, report)
    patch_plat_sepolicy(unpack, payload, args.dry_run, report)
    patch_vendor_sepolicy(unpack, payload, args.dry_run, report)
    patch_framework_jars(root, unpack, args.dry_run, report)
    update_metadata(image_root, unpack, entries, args.dry_run, report)

    out_dir = image_root / "work" / "config"
    out_name = f"zui_control_payload_{stamp()}.json"
    if not args.dry_run:
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir / out_name).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        (out_dir / "zui_control_payload_latest.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
